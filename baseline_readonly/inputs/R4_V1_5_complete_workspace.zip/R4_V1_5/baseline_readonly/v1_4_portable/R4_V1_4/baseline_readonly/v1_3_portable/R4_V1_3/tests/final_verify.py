"""Read-only final verification of frozen evidence plus fresh critical replays."""
import csv,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; PY=sys.executable
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(x,m):
 if not x: raise AssertionError(m)
 print("OK",m)
for manifest_name in ("frozen_manifest_v3.json","results_manifest.json"):
 manifest=json.loads((ROOT/manifest_name).read_text())
 for p,h in manifest.items(): need(sha(ROOT/p)==h,f"{manifest_name}:{p}")
rows=list(csv.DictReader((ROOT/"results.csv").open()))
need(len(rows)==46,"formal row count")
need([r["test_id"] for r in rows if r["status"]=="FAIL"]==["D2_BASE"],"only preserved formatting failure")
need(sum(r["status"]=="MUTATION_DETECTED" for r in rows)==12,"twelve mutants detected")
for p in (ROOT/"supplemental_results.csv",ROOT/"final_adjudication.csv"):
 need(p.is_file(),p.name)
gates={r["gate"]:r["status"] for r in csv.DictReader((ROOT/"final_adjudication.csv").open())}
need(all(gates[x]=="PASS" for x in ("G0","A","B","C","D","E","F")),"final experimental gates pass")
need(gates["THEORY"]=="PENDING","theory remains pending")
def execute(cmd): return subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True,timeout=10)
def compare(subject,oracle):
 with tempfile.TemporaryDirectory(prefix="r4v13_verify_") as d:
  a=Path(d)/"a.json";o=Path(d)/"o.json";a.write_text(subject.stdout);o.write_text(oracle.stdout)
  c=execute([PY,"-B","tests/compare.py",str(a),str(o)])
  need(subject.returncode==oracle.returncode==c.returncode==0,"fresh subject/oracle/comparator")
for model in ("p03_y_uniform_0_1","p03_y_uniform_0_2","p03_y_uniform_0_3_2"):
 compare(execute([PY,"-B","implementations/subject_v3/cli.py","P03",f"models/probability_multihistory/{model}.json"]),execute([PY,"-B","oracles/p03_reference.py",f"models/probability_multihistory/{model}.json"]))
for setting in ("on","off"):
 compare(execute([PY,"-B","implementations/subject_v3/cli.py","CHANNEL","models/r06_observation/discriminative_completion_channel.json",setting]),execute([PY,"-B","oracles/channel_reference.py","models/r06_observation/discriminative_completion_channel.json",setting]))
for model in ("multihistory_base","multihistory_weight_variant"):
 compare(execute([PY,"-B","implementations/subject_v3/cli.py","MULTIHISTORY",f"models/probability_multihistory/{model}.json"]),execute([PY,"-B","oracles/multihistory_reference.py",f"models/probability_multihistory/{model}.json"]))
for model,cert,decision in (("cert_pass_network","pass_exact_replay","\"v_P\": \"1\""),("cert_fail_network","risk_fail_exact_replay","\"v_P\": \"0\"")):
 r=execute([PY,"-B","implementations/certificate_verifier_v3/cli.py",f"models/r04_certificates/{model}.json",f"certificates/valid/{cert}.json"]);need(r.returncode==0 and decision in r.stdout,"fresh valid certificate replay")
for cert in (ROOT/"certificates/forged").glob("*.json"):
 model="models/r04_certificates/legal_priority_frontier.json" if cert.name=="v12_negative_out_of_range.json" else "models/r04_certificates/cert_pass_network.json"
 if cert.stem in {"zero_class_mass","negative_density","invalid_prior_thresholds","post_completion_continuation","unknown_place","invalid_arc","instant_cycle","invalid_label_fault_types"}:model=f"models/r04_certificates/{cert.stem}.json"
 r=execute([PY,"-B","implementations/certificate_verifier_v3/cli.py",model,str(cert.relative_to(ROOT))]);need(r.returncode==2 and "CERTIFICATE_INVALID" in r.stdout,f"forged rejected:{cert.name}")
r=execute([PY,"-B","implementations/subject_v5/logical_module.py","models/cross_layer/e3_overlap_v13.json"]);need(r.returncode==0,"fresh E logical export")
with tempfile.TemporaryDirectory(prefix="r4v13_align_") as d:
 l=Path(d)/"l.json";p=Path(d)/"p.json";l.write_text(r.stdout)
 pr=execute([PY,"-B","implementations/subject_v5/probability_module.py","models/cross_layer/e3_overlap_v13.json","--channel-off"]);p.write_text(pr.stdout)
 ar=execute([PY,"-B","implementations/subject_v5/alignment.py",str(l),str(p)]);need(pr.returncode==0 and ar.returncode==3 and "THEOREM_NOT_APPLICABLE" in ar.stdout,"fresh E channel mismatch")
need("comparator=1" in (ROOT/"runs/F_V2/M10/status.txt").read_text(),"M10 oracle comparison detected")
need("comparator=1" in (ROOT/"runs/F_V2/M11/status.txt").read_text(),"M11 numerical resampling detected")
r=execute([PY,"-B","tests/theory_contract_contrast.py"]);need(r.returncode==0 and "THEORY_CONTRACT_PENDING" in r.stdout,"theory contrast stays pending")
need(not any(p.is_symlink() for p in ROOT.rglob("*")),"no symlinks")
print("FINAL_VERIFY PASS")
