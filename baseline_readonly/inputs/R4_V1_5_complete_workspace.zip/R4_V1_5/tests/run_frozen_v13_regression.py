"""Fresh isolated replay of unaffected V1.3 acceptance and mutations."""

import csv
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FROZEN = (ROOT / "baseline_readonly/v1_4_portable/R4_V1_4/baseline_readonly/"
          "v1_3_portable/R4_V1_3")
EVIDENCE = ROOT / "results/regression/frozen_v13_fresh_replay"
LOGS = ROOT / "logs/regression"
if EVIDENCE.exists():
    raise FileExistsError(f"refusing to overwrite {EVIDENCE}")
EVIDENCE.mkdir(parents=True)
LOGS.mkdir(parents=True, exist_ok=True)


def execute(command, cwd, stem, timeout=240):
    done = subprocess.run(command, cwd=cwd, capture_output=True, text=True,
                          timeout=timeout, check=False)
    (LOGS / f"{stem}.command.json").write_text(json.dumps({
        "command": command, "cwd": str(cwd), "timeout_seconds": timeout,
        "exit_code": done.returncode, "stdout": done.stdout, "stderr": done.stderr,
    }, indent=2) + "\n", encoding="utf-8")
    return done


with tempfile.TemporaryDirectory(prefix="r4v15_v13_replay_") as raw:
    work = Path(raw) / "R4_V1_3"
    shutil.copytree(FROZEN, work)
    historical = work / "frozen_manifest.json"
    authoritative = work / "frozen_manifest_v3.json"
    shutil.copy2(historical, EVIDENCE / "historical_frozen_manifest.json")
    shutil.copy2(authoritative, EVIDENCE / "authoritative_frozen_manifest_v3.json")
    shutil.copy2(authoritative, historical)
    shutil.rmtree(work / "runs")
    (work / "results.csv").unlink()
    suite = execute([sys.executable, "-B", "tests/run_suite.py"], work, "frozen_v13_run_suite")
    if suite.returncode not in (0, 1) or not (work / "results.csv").is_file():
        raise SystemExit("isolated V1.3 suite did not produce results.csv")
    with (work / "results.csv").open(newline="", encoding="utf-8") as stream:
        rows_list = list(csv.DictReader(stream))
    shutil.copy2(work / "results.csv", EVIDENCE / "fresh_results.csv")
    shutil.copytree(work / "runs", EVIDENCE / "fresh_runs")

rows = {row["test_id"]: row for row in rows_list}
required = {
    "A1_C04": "PASS", "A2_C04": "PASS", "A_ENDPOINT": "PASS",
    "A_TRUE_TAIL": "PASS", "B3_VALID_PASS": "PASS", "B3_VALID_FAIL": "PASS",
    "B_ATTACK_IN_RANGE_WRONG": "PASS", "B_ATTACK_MODIFIED_STEP": "PASS",
    "C_R06_BASE": "PASS", "C_CHANNEL_ON": "PASS", "C_CHANNEL_OFF": "PASS",
    "D1_U01": "PASS", "D1_U02": "PASS", "D1_U032": "PASS",
    "E1": "PASS", "E2": "PASS", "E3": "PASS",
    "E_NEG_CHANNEL": "PASS", "E_NEG_COARSEN": "PASS",
    **{f"M{number}_{name}": "MUTATION_DETECTED" for number, name in (
        (1, "TIMESTAMP"), (2, "NO_IMMEDIATE_PRIORITY"), (3, "DROP_FRONTIER"),
        (4, "READ_OBSERVATION_MEASURE"), (5, "KEEP_SELF_CLOCK"),
        (6, "FAKE_CERTIFIED_BOUNDS"), (7, "SHA_ONLY"), (8, "UNIT_SUPPORT"),
        (9, "METADATA_SIGNAL"), (10, "HARDCODE_ALIGNMENT"), (12, "RENORMALIZE"),
    )},
}
checks = {}
for test_id, expected in required.items():
    actual = rows.get(test_id, {}).get("status", "MISSING")
    checks[test_id] = {"expected": expected, "actual": actual, "pass": actual == expected}
summary = {
    "status": "PASS" if all(item["pass"] for item in checks.values()) else "FAIL",
    "execution": "fresh isolated replay on 2026-11-21; not historical-log reuse",
    "excluded": ["D2_BASE replaced by V1.5 structural suite", "old M11 replaced by V1.5 strong mutation"],
    "checks": checks,
}
(EVIDENCE / "regression_summary.json").write_text(
    json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2, sort_keys=True))
raise SystemExit(0 if summary["status"] == "PASS" else 1)
