# R4-V1.3 阶段 I 实验验收

理论基准：第四轮 TeX，SHA-256 `91aa5c1923b41a4030777d6266b466bcfdb20011a56dd7ad26f5b59fa7810e2a`。

## 关卡

- G0: PASS
- A: PASS
- B: PASS（有限全即时精确证书子类）
- C: PASS
- D: PASS（冻结有理多项式/均匀有限历史子类）
- E: PASS
- F: PASS
- 算法 4.1 理论合同：`THEORY_CONTRACT_PENDING`
- 阶段 II：`WAITING_FOR_THEORY_BASELINE`

正式冻结批次共有 46 条：31 PASS、12 `MUTATION_DETECTED`、1 FAIL、1 `THEORY_CONTRACT_PENDING`、1 `WAITING_FOR_THEORY_BASELINE`。唯一 FAIL 是 D2 空前沿的 JSON 类型不一致；它没有被覆盖。版本化 V2/V3 补验修复该格式问题，并加强真实 Pre/Post 持续时钟和逐类别×时间桶独立积分，权威补验记录均 PASS。

交付前深度复核又触发版本化加固：证书验证器 V3 增加完整模型、ID/标号/故障类型、先验/阈值、第一次完成与即时无环检查；跨层模块 V5 从实际路径推导类别正质量与第一次完成，并比较完整历史；M10 使用真实负测 oracle，M11 的错误重抽实际改变第二阶段概率。原始较弱证据均保留，最终裁决使用这些加固结果。

本轮可以声明：**R4-V1.3 定义范围内的受限实验专项补验通过**。这不等于一般 LSTPN 全称理论证明、算法 4.1 冲突、一般连续风险认证或论文理论—实验联合闭合。

未修改论文、TeX 或证明；未恢复或冒充历史 Linux 源码；所有历史失败、伪证书和旧输出均保留。
