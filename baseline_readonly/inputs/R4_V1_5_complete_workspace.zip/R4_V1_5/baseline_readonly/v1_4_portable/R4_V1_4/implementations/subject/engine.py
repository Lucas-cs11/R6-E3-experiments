"""Independent R4-V1.4 experiment kernel for the bounded D2 micro-network.

This is not the unavailable historical Linux implementation and is not a
general LSTPN solver.  It accepts only the declared two-root, three-clock,
U[0,1] model family and fails closed outside that family.
"""

from __future__ import annotations

import hashlib
import json
from fractions import Fraction as F
from pathlib import Path


CATEGORIES = ("Y<X", "X<Y,Z<Y-X", "X<Y,Y-X<Z")


def q(value) -> F:
    return value if isinstance(value, F) else F(str(value))


def encode(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(item) for item in value]
    return value


def sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _validate_marking(places: set[str], marking, name: str) -> None:
    if not isinstance(marking, dict) or not set(marking) <= places:
        raise ValueError(f"{name}: invalid marking places")
    if any(type(count) is not int or count <= 0 for count in marking.values()):
        raise ValueError(f"{name}: invalid marking tokens")


def load_model(path: str | Path) -> dict:
    model = json.loads(Path(path).read_text(encoding="utf-8"))
    required = {"id", "places", "transitions", "initial_marking", "completion",
                "history_branch", "quantization_boundary"}
    if required - set(model):
        raise ValueError(f"missing fields: {sorted(required - set(model))}")
    if "expected" in model:
        raise ValueError("expected answers are forbidden in subject models")
    places = set(model["places"])
    if len(places) != len(model["places"]) or not places:
        raise ValueError("invalid places")
    _validate_marking(places, model["initial_marking"], "initial")
    if not model["completion"]:
        raise ValueError("missing completion markings")
    for index, marking in enumerate(model["completion"]):
        _validate_marking(places, marking, f"completion[{index}]")
    identifiers: set[str] = set()
    for item in model["transitions"]:
        if item["id"] in identifiers:
            raise ValueError("duplicate transition")
        identifiers.add(item["id"])
        _validate_marking(places, item["pre"], f"{item['id']}.pre")
        _validate_marking(places, item["post"], f"{item['id']}.post")
        if item.get("label") is not None and not isinstance(item["label"], str):
            raise ValueError("invalid label")
        if type(item.get("fault", False)) is not bool:
            raise ValueError("invalid fault flag")
        lo, hi = map(q, item["interval"])
        if item.get("kind") == "immediate":
            if (lo, hi) != (0, 0) or q(item.get("weight", 0)) <= 0:
                raise ValueError("invalid immediate transition")
        elif item.get("kind") == "timed":
            distribution = item.get("distribution", {})
            if (lo, hi) != (0, 1) or distribution.get("family") != "uniform":
                raise ValueError("UNSUPPORTED: only timed U[0,1] is certified")
            if list(map(q, distribution.get("support", []))) != [F(0), F(1)]:
                raise ValueError("distribution support differs from interval")
        else:
            raise ValueError("invalid transition kind")
    if not {"x", "y", "z"} <= identifiers:
        raise ValueError("UNSUPPORTED: required x/y/z transitions are absent")
    return model


def transition_table(model: dict) -> dict[str, dict]:
    return {item["id"]: item for item in model["transitions"]}


def enabled(model: dict, marking: dict) -> set[str]:
    return {
        item["id"]
        for item in model["transitions"]
        if all(marking.get(place, 0) >= count for place, count in item["pre"].items())
    }


def fire(model: dict, marking: dict, transition_id: str) -> dict:
    table = transition_table(model)
    if transition_id not in enabled(model, marking):
        raise ValueError(f"transition {transition_id} is not enabled")
    result = dict(marking)
    item = table[transition_id]
    for place, count in item["pre"].items():
        result[place] -= count
        if result[place] == 0:
            del result[place]
    for place, count in item["post"].items():
        result[place] = result.get(place, 0) + count
    return result


def is_complete(model: dict, marking: dict) -> bool:
    return marking in model["completion"]


def terminal_kind(model: dict, marking: dict) -> str:
    if is_complete(model, marking):
        return "completed_first"
    if enabled(model, marking):
        return "unresolved_frontier"
    return "unfinished_deadlock"


def _public_word(table: dict[str, dict], path: list[str]) -> list[str]:
    return [table[item]["label"] for item in path if table[item].get("label") is not None]


def _category_math(boundary: F) -> tuple[dict[str, F], dict[str, F]]:
    if not F(0) <= boundary <= F(1):
        raise ValueError("UNSUPPORTED: quantization boundary must be in [0,1]")
    total = {"Y<X": F(1, 2), "X<Y,Z<Y-X": F(1, 6), "X<Y,Y-X<Z": F(1, 3)}
    early = {
        "Y<X": boundary - boundary**2 / 2,
        "X<Y,Z<Y-X": boundary**2 / 2 - boundary**3 / 3,
        "X<Y,Y-X<Z": boundary**2 / 2 - boundary**3 / 6,
    }
    return total, early


def propagate(model: dict) -> dict:
    table = transition_table(model)
    if is_complete(model, model["initial_marking"]):
        raise ValueError("UNSUPPORTED: initial marking is already complete")
    roots = [
        item for item in model["transitions"]
        if item.get("kind") == "immediate" and item["pre"] == model["initial_marking"]
    ]
    if len(roots) != 2:
        raise ValueError("UNSUPPORTED: exactly two root immediate transitions are required")
    history = next((item for item in roots if item["id"] == model["history_branch"]), None)
    if history is None:
        raise ValueError("history branch is not a root transition")
    bypass = next(item for item in roots if item["id"] != history["id"])
    total_root_weight = sum((q(item["weight"]) for item in roots), F(0))
    history_weight = q(history["weight"]) / total_root_weight
    bypass_weight = q(bypass["weight"]) / total_root_weight

    history_marking = fire(model, model["initial_marking"], history["id"])
    bypass_marking = fire(model, model["initial_marking"], bypass["id"])
    if is_complete(model, history_marking):
        raise ValueError("UNSUPPORTED: history branch completes before timed competition")
    if enabled(model, history_marking) != {"x", "y"}:
        raise ValueError("UNSUPPORTED: history root must enable exactly x and y")
    after_x = fire(model, history_marking, "x")
    if is_complete(model, after_x):
        raise ValueError("UNSUPPORTED: first completion occurs at intermediate X firing")
    if enabled(model, after_x) != {"y", "z"}:
        raise ValueError("UNSUPPORTED: firing x must enable persistent y and new z")

    paths = {
        "Y<X": [history["id"], "y"],
        "X<Y,Z<Y-X": [history["id"], "x", "z"],
        "X<Y,Y-X<Z": [history["id"], "x", "y"],
    }
    markings = {
        "Y<X": fire(model, history_marking, "y"),
        "X<Y,Z<Y-X": fire(model, after_x, "z"),
        "X<Y,Y-X<Z": fire(model, after_x, "y"),
    }
    boundary = q(model["quantization_boundary"])
    category_total, category_early = _category_math(boundary)
    budget = int(model.get("path_budget", len(CATEGORIES)))
    if budget < 0:
        raise ValueError("path_budget must be nonnegative")

    terminal_leaves = []
    histories = []
    buckets = []
    termination_mass = {
        "completed_first": F(0),
        "unfinished_deadlock": F(0),
        "other_resolved": F(0),
        "unresolved_frontier": F(0),
    }

    bypass_kind = terminal_kind(model, bypass_marking)
    bypass_entry = {
        "leaf_id": "bypass",
        "source": "root_immediate",
        "path": [bypass["id"]],
        "fired_transition": bypass["id"],
        "successor_marking": bypass_marking,
        "public_word": _public_word(table, [bypass["id"]]),
        "fault": bool(bypass.get("fault", False)),
        "mass": bypass_weight,
        "termination": bypass_kind,
        "resolved": bypass_kind != "unresolved_frontier",
    }
    terminal_leaves.append(bypass_entry)
    termination_mass[bypass_kind] += bypass_weight

    for index, category in enumerate(CATEGORIES):
        conditional_mass = category_total[category]
        network_mass = history_weight * conditional_mass
        resolved = index < budget
        kind = terminal_kind(model, markings[category]) if resolved else "unresolved_frontier"
        path = paths[category]
        history_entry = {
            "category": category,
            "parent": history["id"],
            "conditional_mass": conditional_mass,
            "network_mass": network_mass,
            "path": path,
            "successor_marking": markings[category],
            "public_word": _public_word(table, path),
            "fault": any(bool(table[item].get("fault", False)) for item in path),
            "termination": kind,
            "resolved": resolved,
            "clock_instances": {
                "before_x": {"x": "x#1", "y": "y#1"},
                "after_x": {"y": "y#1", "z": "z#1"} if category.startswith("X<Y") else None,
                "y_persistent": category.startswith("X<Y"),
            },
        }
        histories.append(history_entry)
        termination_mass[kind] += network_mass
        if resolved:
            terminal_leaves.append({
                "leaf_id": category,
                "source": "timed_history",
                "path": path,
                "successor_marking": markings[category],
                "public_word": history_entry["public_word"],
                "fault": history_entry["fault"],
                "mass": network_mass,
                "termination": kind,
                "resolved": True,
            })
            for bucket, conditional_bucket_mass in (
                (f"t<={boundary}", category_early[category]),
                (f"t>{boundary}", conditional_mass - category_early[category]),
            ):
                buckets.append({
                    "category": category,
                    "bucket": bucket,
                    "conditional_mass": conditional_bucket_mass,
                    "network_mass": history_weight * conditional_bucket_mass,
                    "public_word": history_entry["public_word"],
                    "termination": kind,
                })

    resolved_mass = sum(
        (item["mass"] for item in terminal_leaves if item["resolved"]), F(0)
    )
    frontier_mass = termination_mass["unresolved_frontier"]
    completed_mass = termination_mass["completed_first"]
    completed_observations: dict[tuple[str, ...], F] = {}
    for leaf in terminal_leaves:
        if leaf["termination"] == "completed_first":
            key = tuple(leaf["public_word"])
            completed_observations[key] = completed_observations.get(key, F(0)) + leaf["mass"]
    conditioning_status = "RESOLVED" if frontier_mass == 0 else "UNRESOLVED"
    completed_conditional = {
        "status": conditioning_status,
        "event": "completed_first",
        "known_denominator": completed_mass,
        "observations": {
            "|".join(key): mass / completed_mass
            for key, mass in completed_observations.items()
        } if completed_mass and conditioning_status == "RESOLVED" else {},
    }
    metadata = model.get("bypass_label", None)
    metadata_consistency = (
        "ABSENT" if "bypass_label" not in model
        else "MATCH" if metadata == bypass.get("label")
        else "MISMATCH_IGNORED"
    )
    return {
        "implementation_scope": "bounded_two_root_three_clock_u01",
        "model_id": model["id"],
        "root": {
            "history_transition": history["id"],
            "history_mass": history_weight,
            "bypass_transition": bypass["id"],
            "bypass_mass": bypass_weight,
        },
        "bypass": bypass_entry,
        "bypass_metadata_consistency": metadata_consistency,
        "histories": histories,
        "quantized_joint": buckets,
        "terminal_leaves": terminal_leaves,
        "termination_mass": termination_mass,
        "processed_mass": resolved_mass,
        "frontier_mass": frontier_mass,
        "mass_total": resolved_mass + frontier_mass,
        "completed_conditioning": completed_conditional,
        "budget": budget,
        "quantization_boundary": boundary,
        "integration_regions": {
            "Y<X": "0<=y<x<=1",
            "X<Y,Z<Y-X": "0<=x<y<=1, 0<=z<y-x",
            "X<Y,Y-X<Z": "0<=x<y<=1, y-x<z<=1",
        },
    }
