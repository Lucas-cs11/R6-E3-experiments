"""Normal clock policy: preserve exactly the structurally persistent clocks."""


def adjust_clock_sets(fired, persistent, newly_enabled):
    return persistent, newly_enabled, []
