"""M12: drop the unresolved frontier and report processed mass as one."""
import json,sys
sys.path.insert(0,"implementations/subject")
from engine import encode,load_model,multihistory_propagation
model=load_model(sys.argv[1],probability=True)
print(json.dumps(encode(multihistory_propagation(model,drop_frontier_mutant=True)),indent=2))
