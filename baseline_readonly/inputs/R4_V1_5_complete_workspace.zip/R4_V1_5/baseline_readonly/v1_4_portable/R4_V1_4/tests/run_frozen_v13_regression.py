"""Replay the unchanged R4-V1.3 suite in an isolated temporary copy.

The frozen V1.3 tree remains read-only.  D2 and old M11 are not accepted from
this replay; they are replaced by the V1.4 tests.  All other required accepted
regressions and mutations must retain their prior status.
"""

from __future__ import annotations

import csv
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / "baseline_readonly" / "v1_3_portable" / "R4_V1_3"
EVIDENCE = ROOT / "runs" / "regression" / "frozen_v13_replay"
if EVIDENCE.exists():
    raise FileExistsError(f"refusing to overwrite regression evidence: {EVIDENCE}")
EVIDENCE.mkdir(parents=True)


def execute(command, cwd, stem, timeout=180):
    completed = subprocess.run(
        command, cwd=cwd, capture_output=True, text=True, timeout=timeout, check=False
    )
    (EVIDENCE / f"{stem}.command.json").write_text(
        json.dumps({"command": command, "cwd": str(cwd), "timeout_seconds": timeout}, indent=2) + "\n",
        encoding="utf-8",
    )
    (EVIDENCE / f"{stem}.stdout").write_text(completed.stdout, encoding="utf-8")
    (EVIDENCE / f"{stem}.stderr").write_text(completed.stderr, encoding="utf-8")
    (EVIDENCE / f"{stem}.exit").write_text(f"{completed.returncode}\n", encoding="utf-8")
    return completed


with tempfile.TemporaryDirectory(prefix="r4v14_v13_replay_") as raw:
    work = Path(raw) / "R4_V1_3"
    shutil.copytree(FROZEN, work)
    # V1.3 kept the earlier manifest as historical evidence, while its final
    # verifier and release use frozen_manifest_v3.json.  Point the isolated
    # replay at that authoritative version without touching the frozen source.
    old_manifest = work / "frozen_manifest.json"
    authoritative_manifest = work / "frozen_manifest_v3.json"
    shutil.copy2(old_manifest, EVIDENCE / "historical_frozen_manifest.json")
    shutil.copy2(authoritative_manifest, EVIDENCE / "authoritative_frozen_manifest_v3.json")
    shutil.copy2(authoritative_manifest, old_manifest)
    (EVIDENCE / "manifest_entrypoint_note.txt").write_text(
        "Isolated replay redirects frozen_manifest.json to the already-frozen "
        "frozen_manifest_v3.json. The source V1.3 tree is unchanged.\n",
        encoding="utf-8",
    )
    # The historical package contains immutable prior logs, while run_suite.py
    # deliberately creates every evidence directory with exclusive semantics.
    # Remove logs only from this disposable copy so the replay is genuinely new.
    shutil.rmtree(work / "runs")
    (work / "results.csv").unlink()
    (EVIDENCE / "temporary_copy_cleanup_note.txt").write_text(
        "Removed pre-existing runs/ and results.csv only inside the disposable "
        "temporary copy because the runner requires exclusive evidence paths.\n",
        encoding="utf-8",
    )
    suite = execute([sys.executable, "-B", "tests/run_suite.py"], work, "run_suite")
    if suite.returncode not in (0, 1) or not (work / "results.csv").is_file():
        raise SystemExit("V1.3 isolated run_suite did not produce a result table")
    with (work / "results.csv").open(newline="", encoding="utf-8") as stream:
        replay_rows = list(csv.DictReader(stream))
    preserved_failures = [row["test_id"] for row in replay_rows if row["status"] == "FAIL"]
    if preserved_failures != ["D2_BASE"]:
        raise SystemExit(f"unexpected V1.3 replay failures: {preserved_failures}")
    shutil.copy2(work / "results.csv", EVIDENCE / "fresh_results.csv")
    shutil.copytree(work / "runs", EVIDENCE / "fresh_runs")

    rows = {row["test_id"]: row for row in replay_rows}

required = {
    "A1_C04": "PASS",
    "A2_C04": "PASS",
    "A_ENDPOINT": "PASS",
    "A_TRUE_TAIL": "PASS",
    "B3_VALID_PASS": "PASS",
    "B3_VALID_FAIL": "PASS",
    "B_ATTACK_IN_RANGE_WRONG": "PASS",
    "B_ATTACK_MODIFIED_STEP": "PASS",
    "C_R06_BASE": "PASS",
    "C_CHANNEL_ON": "PASS",
    "C_CHANNEL_OFF": "PASS",
    "D1_U01": "PASS",
    "D1_U02": "PASS",
    "D1_U032": "PASS",
    "E1": "PASS",
    "E2": "PASS",
    "E3": "PASS",
    "E_NEG_CHANNEL": "PASS",
    "E_NEG_COARSEN": "PASS",
    **{f"M{number}_{name}": "MUTATION_DETECTED" for number, name in (
        (1, "TIMESTAMP"),
        (2, "NO_IMMEDIATE_PRIORITY"),
        (3, "DROP_FRONTIER"),
        (4, "READ_OBSERVATION_MEASURE"),
        (5, "KEEP_SELF_CLOCK"),
        (6, "FAKE_CERTIFIED_BOUNDS"),
        (7, "SHA_ONLY"),
        (8, "UNIT_SUPPORT"),
        (9, "METADATA_SIGNAL"),
        (10, "HARDCODE_ALIGNMENT"),
        (12, "RENORMALIZE"),
    )},
}
checks = {}
for test_id, expected in required.items():
    actual = rows.get(test_id, {}).get("status", "MISSING")
    checks[test_id] = {"expected": expected, "actual": actual, "pass": actual == expected}

summary = {
    "status": "PASS" if all(item["pass"] for item in checks.values()) else "FAIL",
    "note": "old D2 and old M11 are deliberately excluded and replaced by V1.4",
    "checks": checks,
}
(EVIDENCE / "regression_summary.json").write_text(
    json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(json.dumps(summary, indent=2, sort_keys=True))
raise SystemExit(0 if summary["status"] == "PASS" else 1)
