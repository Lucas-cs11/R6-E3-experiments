"""CLI for the bounded R4-V1.4 D2 subject."""

import json
import sys

from engine import encode, load_model, propagate


if len(sys.argv) != 2:
    raise SystemExit("usage: cli.py MODEL.json")

try:
    model = load_model(sys.argv[1])
    print(json.dumps(encode(propagate(model)), indent=2, sort_keys=True))
except Exception as exc:
    print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
    raise SystemExit(2)
