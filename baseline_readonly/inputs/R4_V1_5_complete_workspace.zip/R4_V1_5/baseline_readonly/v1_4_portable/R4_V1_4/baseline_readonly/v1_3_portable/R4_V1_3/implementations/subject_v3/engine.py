"""R4-V1.3 NEW_VALIDATION_IMPLEMENTATION.

Exact, bounded experiment kernel for the frozen micro-networks in this delivery.
It is deliberately not presented as the unavailable historical Linux program or
as a general TPN/LSTPN solver.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from collections import deque
from fractions import Fraction as Q
from pathlib import Path


def q(value):
    return value if isinstance(value, Q) else Q(str(value))


def encode(value):
    if isinstance(value, Q):
        return str(value)
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [encode(v) for v in value]
    return value


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_model(path, probability=False):
    model = json.loads(Path(path).read_text())
    required = {"id", "places", "transitions", "initial_marking", "completion"}
    missing = required - set(model)
    if missing:
        raise ValueError(f"missing fields: {sorted(missing)}")
    if "expected" in model:
        raise ValueError("expected answers are forbidden in subject models")
    places = set(model["places"])
    if not places or len(places) != len(model["places"]):
        raise ValueError("invalid places")
    ids = set()
    for transition in model["transitions"]:
        tid = transition["id"]
        if tid in ids:
            raise ValueError("duplicate transition")
        ids.add(tid)
        if not set(transition["pre"]) <= places or not set(transition["post"]) <= places:
            raise ValueError("unknown place")
        if any(type(v) is not int or v <= 0 for v in [*transition["pre"].values(), *transition["post"].values()]):
            raise ValueError("invalid arc weight")
        lo, hi = map(q, transition["interval"])
        if lo < 0 or hi < lo:
            raise ValueError("invalid interval")
        kind = transition.get("kind", "timed")
        if kind == "immediate":
            if (lo, hi) != (0, 0) or q(transition.get("weight", 0)) <= 0:
                raise ValueError("invalid immediate transition")
        elif kind == "timed":
            if probability:
                if not lo < hi:
                    raise ValueError("LSTPN timed transition requires a_t < b_t")
                validate_distribution(transition.get("distribution"), lo, hi)
        else:
            raise ValueError("invalid transition kind")
        if transition.get("label") is not None and not isinstance(transition["label"], str):
            raise ValueError("invalid label")
        if type(transition.get("fault", False)) is not bool:
            raise ValueError("invalid fault flag")
    validate_marking(model, model["initial_marking"])
    if not model["completion"]:
        raise ValueError("missing completion markings")
    for marking in model["completion"]:
        validate_marking(model, marking)
    return model


def validate_marking(model, marking):
    if not isinstance(marking, dict) or not set(marking) <= set(model["places"]):
        raise ValueError("invalid marking places")
    if any(type(v) is not int or v <= 0 for v in marking.values()):
        raise ValueError("invalid marking tokens")


def validate_distribution(distribution, lo, hi):
    if not isinstance(distribution, dict):
        raise ValueError("missing timed distribution")
    if list(map(q, distribution.get("support", []))) != [lo, hi]:
        raise ValueError("distribution support differs from interval")
    family = distribution.get("family")
    if family == "uniform":
        if distribution.keys() - {"family", "support"}:
            raise ValueError("unexpected uniform parameters")
    elif family == "linear_2x":
        if (lo, hi) != (0, 1):
            raise ValueError("linear_2x is normalized only on [0,1]")
    elif family == "sqrt_inv":
        if (lo, hi) != (0, 1):
            raise ValueError("sqrt_inv is normalized only on [0,1]")
    else:
        raise ValueError("UNSUPPORTED_DISTRIBUTION")


def transitions(model):
    return {t["id"]: t for t in model["transitions"]}


def enabled(model, marking):
    return {t["id"] for t in model["transitions"]
            if all(marking.get(place, 0) >= count for place, count in t["pre"].items())}


def fire_with_middle(model, marking, tid):
    table = transitions(model)
    if tid not in enabled(model, marking):
        raise ValueError(f"transition {tid} is not enabled")
    t = table[tid]
    middle = dict(marking)
    for place, count in t["pre"].items():
        middle[place] -= count
        if middle[place] == 0:
            del middle[place]
    after = dict(middle)
    for place, count in t["post"].items():
        after[place] = after.get(place, 0) + count
    return middle, after


def fire(model, marking, tid):
    return fire_with_middle(model, marking, tid)[1]


def is_complete(model, marking):
    return marking in model["completion"]


def add_inequality(rows, coeff, rhs, reason):
    rows.append(({k: q(v) for k, v in coeff.items() if q(v)}, q(rhs), reason))


def affine_add(left, right):
    result = dict(left)
    for key, value in right.items():
        result[key] = result.get(key, Q(0)) + value
        if not result[key]:
            del result[key]
    return result


def path_polytope(model, path, prefix):
    table = transitions(model)
    marking = dict(model["initial_marking"])
    ages = {tid: {} for tid in enabled(model, marking)}
    variables, rows, visible = [], [], []
    total = {}
    fault = False
    if is_complete(model, marking):
        raise ValueError("initial marking is already complete")
    for index, tid in enumerate(path):
        if tid not in table or tid not in enabled(model, marking):
            raise ValueError(f"structurally invalid path at {tid}")
        active = enabled(model, marking)
        immediate = {u for u in active if table[u].get("kind", "timed") == "immediate"}
        if immediate and table[tid].get("kind", "timed") != "immediate":
            raise ValueError("timed firing attempted while immediate transition enabled")
        variable = f"{prefix}{index}"
        variables.append(variable)
        delay = {variable: Q(1)}
        add_inequality(rows, {variable: -1}, 0, f"{tid}:delay_nonnegative")
        lo, hi = map(q, table[tid]["interval"])
        fired_age = affine_add(ages[tid], delay)
        add_inequality(rows, {k: -v for k, v in fired_age.items()}, -lo, f"{tid}:earliest")
        for active_tid in sorted(active):
            upper = q(table[active_tid]["interval"][1])
            age_at_fire = affine_add(ages[active_tid], delay)
            add_inequality(rows, age_at_fire, upper, f"{active_tid}:latest@{tid}")
        total = affine_add(total, delay)
        label = table[tid].get("label")
        if label is not None:
            visible.append(label)
        fault = fault or table[tid].get("fault", False)
        middle, after = fire_with_middle(model, marking, tid)
        persistent = (active & enabled(model, middle) & enabled(model, after)) - {tid}
        new_ages = {}
        for active_tid in enabled(model, after):
            new_ages[active_tid] = affine_add(ages[active_tid], delay) if active_tid in persistent else {}
        marking, ages = after, new_ages
        if is_complete(model, marking) and index != len(path) - 1:
            raise ValueError("path continues after first completion")
    if not is_complete(model, marking):
        raise ValueError("path does not reach completion")
    horizon = q(model.get("H", 1000))
    add_inequality(rows, total, horizon, "global_horizon")
    return {"variables": variables, "constraints": rows, "visible": visible,
            "total": total, "fault": fault, "final_marking": marking}


def gaussian(matrix, vector):
    n = len(vector)
    augmented = [[q(x) for x in row] + [q(v)] for row, v in zip(matrix, vector)]
    row = 0
    for col in range(n):
        pivot = next((r for r in range(row, n) if augmented[r][col]), None)
        if pivot is None:
            return None
        augmented[row], augmented[pivot] = augmented[pivot], augmented[row]
        scale = augmented[row][col]
        augmented[row] = [x / scale for x in augmented[row]]
        for r in range(n):
            if r != row and augmented[r][col]:
                scale = augmented[r][col]
                augmented[r] = [x - scale * y for x, y in zip(augmented[r], augmented[row])]
        row += 1
    return [augmented[i][-1] for i in range(n)]


def vertex_witness(variables, constraints):
    n = len(variables)
    for chosen in itertools.combinations(constraints, n):
        solution = gaussian([[coeff.get(v, 0) for v in variables] for coeff, _, _ in chosen],
                            [rhs for _, rhs, _ in chosen])
        if solution is None:
            continue
        point = dict(zip(variables, solution))
        if all(sum(coeff.get(v, 0) * point[v] for v in variables) <= rhs
               for coeff, rhs, _ in constraints):
            return point
    return None


def fourier_motzkin(variables, constraints):
    rows = [(dict(coeff), rhs, (reason,)) for coeff, rhs, reason in constraints]
    for variable in variables:
        positive = [r for r in rows if r[0].get(variable, 0) > 0]
        negative = [r for r in rows if r[0].get(variable, 0) < 0]
        zero = [r for r in rows if r[0].get(variable, 0) == 0]
        next_rows = [(dict(c), rhs, p) for c, rhs, p in zero]
        for pc, pr, pp in positive:
            for nc, nr, np in negative:
                a, b = pc[variable], nc[variable]
                coeff = {}
                for key in set(pc) | set(nc):
                    if key == variable:
                        continue
                    value = (-b) * pc.get(key, 0) + a * nc.get(key, 0)
                    if value:
                        coeff[key] = value
                next_rows.append((coeff, (-b) * pr + a * nr, pp + np))
        rows = next_rows
        contradiction = next((r for r in rows if not r[0] and r[1] < 0), None)
        if contradiction:
            return False, {"rhs": contradiction[1], "provenance": contradiction[2]}
    return True, None


def replay_delays(model, path, delays):
    table = transitions(model)
    marking = dict(model["initial_marking"])
    ages = {tid: Q(0) for tid in enabled(model, marking)}
    now = Q(0)
    visible = []
    trace = []
    for tid, delay in zip(path, delays):
        delay = q(delay)
        active = enabled(model, marking)
        immediate = {u for u in active if table[u].get("kind", "timed") == "immediate"}
        if immediate and table[tid].get("kind", "timed") != "immediate":
            raise ValueError("immediate priority violation")
        if tid not in active:
            raise ValueError("replay firing is not enabled")
        elapsed = {u: ages[u] + delay for u in active}
        if any(elapsed[u] > q(table[u]["interval"][1]) for u in active):
            raise ValueError("replay urgency violation")
        if elapsed[tid] < q(table[tid]["interval"][0]):
            raise ValueError("replay earliest violation")
        now += delay
        if table[tid].get("label") is not None:
            visible.append({"label": table[tid]["label"], "hidden_timestamp": now})
        middle, after = fire_with_middle(model, marking, tid)
        persistent = (active & enabled(model, middle) & enabled(model, after)) - {tid}
        ages = {u: elapsed[u] if u in persistent else Q(0) for u in enabled(model, after)}
        marking = after
        trace.append({"transition": tid, "delay": delay, "time": now, "marking": marking,
                      "enabled_after": sorted(enabled(model, marking)), "ages_after": ages})
    if not is_complete(model, marking):
        raise ValueError("replay did not reach completion")
    return {"word": [x["label"] for x in visible], "total_time": now,
            "visible_events": visible, "trace": trace, "final_marking": marking}


def c04_coupling(model, timestamp_mutant=False):
    candidate = model["candidate"]
    normal_path, fault_path = candidate["normal_path"], candidate["fault_path"]
    normal = path_polytope(model, normal_path, "n")
    fault = path_polytope(model, fault_path, "f")
    if normal["fault"] or not fault["fault"]:
        raise ValueError("candidate fault classes are invalid")
    if normal["visible"] != fault["visible"]:
        return {"status": "WORD_MISMATCH", "feasible": False, "witness": None}
    variables = normal["variables"] + fault["variables"]
    constraints = normal["constraints"] + fault["constraints"]
    equality = dict(normal["total"])
    for key, value in fault["total"].items():
        equality[key] = equality.get(key, 0) - value
    add_inequality(constraints, equality, 0, "total_duration:eq+")
    add_inequality(constraints, {k: -v for k, v in equality.items()}, 0, "total_duration:eq-")
    if timestamp_mutant:
        normal_prefix, fault_prefix = {}, {}
        for index in range(min(len(normal_path), len(fault_path))):
            normal_prefix[f"n{index}"] = Q(1)
            fault_prefix[f"f{index}"] = Q(1)
            if transitions(model)[normal_path[index]].get("label") is not None:
                row = dict(normal_prefix)
                for key, value in fault_prefix.items():
                    row[key] = row.get(key, 0) - value
                add_inequality(constraints, row, 0, f"MUTANT_hidden_timestamp_{index}:+")
                add_inequality(constraints, {k: -v for k, v in row.items()}, 0,
                               f"MUTANT_hidden_timestamp_{index}:-")
    feasible, contradiction = fourier_motzkin(variables, constraints)
    witness = vertex_witness(variables, constraints) if feasible else None
    if feasible and witness is None:
        raise AssertionError("feasible bounded polytope has no recovered vertex")
    replay = None
    if witness:
        normal_run = replay_delays(model, normal_path, [witness[v] for v in normal["variables"]])
        fault_run = replay_delays(model, fault_path, [witness[v] for v in fault["variables"]])
        if normal_run["word"] != fault_run["word"] or normal_run["total_time"] != fault_run["total_time"]:
            raise AssertionError("coupling witness does not have equal logical observation")
        replay = {"normal": normal_run, "fault": fault_run}
    return {"status": "COUPLED_FEASIBLE" if feasible else "COUPLED_INFEASIBLE",
            "feasible": feasible, "observation_contract": "word_plus_total_completion_time",
            "hidden_event_timestamps_coupled": timestamp_mutant,
            "constraint_count": len(constraints), "witness": witness, "replay": replay,
            "contradiction": contradiction,
            "constraint_reasons": [reason for _, _, reason in constraints]}


def immediate_closure(model, ignore_priority=False):
    table = transitions(model)
    queue = deque([(dict(model["initial_marking"]), Q(1), False, [], [], Q(0))])
    leaves = []
    while queue:
        marking, mass, fault, path, word, now = queue.popleft()
        active = enabled(model, marking)
        immediate = sorted(u for u in active if table[u].get("kind") == "immediate")
        if immediate:
            total = sum((q(table[u]["weight"]) for u in immediate), Q(0))
            for tid in immediate:
                t = table[tid]
                after = fire(model, marking, tid)
                next_word = word + ([t["label"]] if t.get("label") is not None else [])
                queue.append((after, mass * q(t["weight"]) / total, fault or t.get("fault", False),
                              path + [tid], next_word, now))
            if not ignore_priority:
                continue
        leaves.append({"marking": marking, "mass": mass, "fault": fault, "path": path,
                       "word": word, "time": now, "active": sorted(active)})
    return leaves


def r04_account(model, budget, drop_frontier=False, ignore_priority=False):
    table = transitions(model)
    branches = immediate_closure(model, ignore_priority=ignore_priority)
    order = model["solver_policy"]["branch_order"]
    by_root = {leaf["path"][0]: leaf for leaf in branches}
    processed = []
    frontier = []
    uncertified = []
    for index, root_tid in enumerate(order):
        leaf = by_root[root_tid]
        active_timed = [u for u in leaf["active"] if table[u].get("kind") == "timed"]
        if index >= budget:
            frontier.append({"branch": root_tid, "state": leaf["marking"], "mass": leaf["mass"]})
            continue
        if len(active_timed) != 1:
            raise ValueError("R04 branch must have one timed successor")
        timed = table[active_timed[0]]
        family = timed["distribution"]["family"]
        if family == "sqrt_inv":
            uncertified.append({"branch": root_tid, "transition": timed["id"], "mass": leaf["mass"],
                                "reason": "EXACT_POLYNOMIAL_INTEGRATOR_UNSUPPORTED",
                                "legal_density": "1/(2*sqrt(x)) on (0,1]"})
        else:
            after = fire(model, leaf["marking"], timed["id"])
            processed.append({"branch": root_tid, "transition": timed["id"], "mass": leaf["mass"],
                              "completed": is_complete(model, after)})
    processed_mass = sum((x["mass"] for x in processed), Q(0))
    frontier_mass = Q(0) if drop_frontier else sum((x["mass"] for x in frontier), Q(0))
    uncertified_mass = sum((x["mass"] for x in uncertified), Q(0))
    total = processed_mass + frontier_mass + uncertified_mass
    status = "NOT_CERTIFIED" if uncertified or frontier else "CERTIFIED"
    bounds = None if status == "NOT_CERTIFIED" else [processed_mass, processed_mass]
    return {"status": status, "bounds": bounds, "processed": processed, "frontier": frontier,
            "uncertified": uncertified, "processed_mass": processed_mass,
            "frontier_mass": frontier_mass, "uncertified_mass": uncertified_mass,
            "mass_total": total, "frontier_is_network_transition": False,
            "immediate_priority_enforced": not ignore_priority}


def distribution_density(distribution):
    family = distribution["family"]
    lo, hi = map(q, distribution["support"])
    if family == "uniform":
        return {0: Q(1) / (hi - lo)}
    if family == "linear_2x":
        return {1: Q(2)}
    raise ValueError("NOT_CERTIFIED")


def derive_r06_measure(model, ignore_priority=False, read_forbidden_hint=False):
    if read_forbidden_hint and "observation_measure" in model:
        return model["observation_measure"]
    table = transitions(model)
    root_leaves = immediate_closure(model, ignore_priority=ignore_priority)
    joint = []
    for leaf in root_leaves:
        if is_complete(model, leaf["marking"]):
            if len(leaf["word"]) != 1:
                raise ValueError("atom completion needs one external label")
            joint.append({"class": "fault" if leaf["fault"] else "normal", "kind": "atom",
                          "observation": leaf["word"][0], "mass": leaf["mass"], "path": leaf["path"]})
            continue
        active = enabled(model, leaf["marking"])
        timed = [table[u] for u in active if table[u].get("kind") == "timed"]
        immediate = [table[u] for u in active if table[u].get("kind") == "immediate"]
        if immediate and not ignore_priority:
            raise AssertionError("immediate closure incomplete")
        if len(timed) != 1:
            raise ValueError("R06 leaf must enable exactly one timed transition")
        t = timed[0]
        after = fire(model, leaf["marking"], t["id"])
        if not is_complete(model, after) or t.get("label") is None:
            raise ValueError("R06 timed path lacks external completion observation")
        joint.append({"class": "fault" if leaf["fault"] else "normal", "kind": "continuous",
                      "observation": t["label"], "mass": leaf["mass"], "path": leaf["path"] + [t["id"]],
                      "distribution": t["distribution"]})
    class_mass = {name: sum((x["mass"] for x in joint if x["class"] == name), Q(0))
                  for name in ("normal", "fault")}
    conditional = []
    for row in joint:
        conditional.append(dict(row, conditional_mass=row["mass"] / class_mass[row["class"]]))
    prior = {"normal": q(model["decision_prior"][0]), "fault": q(model["decision_prior"][1])}
    atom = {}
    continuous = []
    for row in conditional:
        if row["kind"] == "atom":
            atom.setdefault(row["observation"], {})[row["class"]] = row["conditional_mass"]
        else:
            density = distribution_density(row["distribution"])
            continuous.append({"class": row["class"], "observation": row["observation"],
                               "support": row["distribution"]["support"],
                               "conditional_mass": row["conditional_mass"],
                               "density": {power: coeff * row["conditional_mass"] for power, coeff in density.items()}})
    atom_risk = coverage = Q(0)
    delta = q(model["delta"])
    atom_detail = []
    for observation, masses in atom.items():
        weighted = [prior[name] * masses.get(name, Q(0)) for name in ("normal", "fault")]
        error = min(weighted)
        total = sum(weighted)
        posterior = error / total if total else Q(0)
        atom_risk += error
        if total and posterior <= delta:
            coverage += total
        atom_detail.append({"observation": observation, "weighted": weighted, "posterior_error": posterior})
    continuous_risk = Q(0)
    segment_detail = []
    posterior_values = []
    for observation in sorted({row["observation"] for row in continuous}):
        rows = [row for row in continuous if row["observation"] == observation]
        boundaries = sorted({q(value) for row in rows for value in row["support"]})
        for lo, hi in zip(boundaries, boundaries[1:]):
            weighted_density = []
            for name in ("normal", "fault"):
                density = Q(0)
                for row in rows:
                    if row["class"] == name and q(row["support"][0]) <= lo and hi <= q(row["support"][1]):
                        if set(row["density"]) != {0}:
                            raise ValueError("R06 audit supports constant density only")
                        density += row["density"][0]
                weighted_density.append(prior[name] * density)
            total_density = sum(weighted_density)
            if not total_density:
                continue
            point_error = min(weighted_density)
            posterior = point_error / total_density
            posterior_values.append(posterior)
            mass = (hi - lo) * total_density
            risk_piece = (hi - lo) * point_error
            continuous_risk += risk_piece
            if posterior <= delta:
                coverage += mass
            segment_detail.append({"observation": observation, "interval": [lo, hi],
                                   "weighted_density": weighted_density,
                                   "posterior_error": posterior, "risk": risk_piece,
                                   "total_mass": mass})
    continuous_posterior = posterior_values[0] if len(set(posterior_values)) == 1 else None
    return {"joint_paths": joint, "class_mass": class_mass, "conditional_paths": conditional,
            "atoms": atom_detail, "continuous": continuous, "bayes_error": atom_risk + continuous_risk,
            "continuous_segments": segment_detail, "reliable_coverage": coverage,
            "continuous_posterior_error": continuous_posterior,
            "prior_applied_once": True, "external_completion_signal": model["external_completion_signal"]}


def simulate_clocks(model, keep_self_old=False):
    table = transitions(model)
    marking = dict(model["initial_marking"])
    samples = {tid: [q(v) for v in values] for tid, values in model["deterministic_samples"].items()}
    counters = {tid: 1 for tid in samples}
    active = enabled(model, marking)
    if set(samples) != active:
        raise ValueError("deterministic sample streams do not match initially enabled clocks")
    clocks = {tid: {"instance": f"{tid}#1", "sample": values[0], "age": Q(0)}
              for tid, values in samples.items()}
    trace = []
    for _ in range(model["deterministic_steps"]):
        immediate = [u for u in active if table[u].get("kind") == "immediate"]
        if immediate:
            raise ValueError("positive time advance while immediate transition enabled")
        tid = min(active, key=lambda u: (clocks[u]["sample"] - clocks[u]["age"], u))
        delay = clocks[tid]["sample"] - clocks[tid]["age"]
        before = {u: dict(clocks[u]) for u in active}
        for u in active:
            clocks[u]["age"] += delay
        middle, after = fire_with_middle(model, marking, tid)
        persistent = (active & enabled(model, middle) & enabled(model, after)) - {tid}
        after_active = enabled(model, after)
        next_clocks = {u: clocks[u] for u in persistent}
        for u in after_active - persistent:
            if u == tid and keep_self_old:
                next_clocks[u] = clocks[u]
                continue
            counters[u] = counters.get(u, 0) + 1
            index = counters[u] - 1
            if index >= len(samples[u]):
                raise ValueError(f"missing deterministic sample for {u} instance {counters[u]}")
            next_clocks[u] = {"instance": f"{u}#{counters[u]}", "sample": samples[u][index], "age": Q(0)}
        trace.append({"fired": tid, "delay": delay, "before": before, "middle": middle,
                      "marking_after": after, "persistent": sorted(persistent),
                      "clocks_after": {u: dict(next_clocks[u]) for u in sorted(next_clocks)}})
        marking, active, clocks = after, after_active, next_clocks
    return {"trace": trace, "final_marking": marking, "active": sorted(active)}


def poly_integral_0_to_y(poly_x):
    return {power + 1: coeff / (power + 1) for power, coeff in poly_x.items()}


def integrate_poly_0_to(poly, upper):
    return sum(coeff * upper ** (power + 1) / (power + 1) for power, coeff in poly.items())


def nonuniform_competition(model):
    table = transitions(model)
    active = enabled(model, model["initial_marking"])
    if len(active) != 2 or any(table[u].get("kind") != "timed" for u in active):
        raise ValueError("competition requires exactly two timed clocks")
    x = next(u for u in active if table[u]["distribution"]["family"] == "linear_2x")
    y = next(u for u in active if table[u]["distribution"]["family"] == "uniform")
    fx = distribution_density(table[x]["distribution"])
    # P(X<Y)=integral_0^1 f_X(x)*(1-x) dx.
    win_poly = dict(fx)
    for power, coeff in list(fx.items()):
        win_poly[power + 1] = win_poly.get(power + 1, 0) - coeff
    p_x = integrate_poly_0_to(win_poly, Q(1))
    p_y = Q(1) - p_x
    # numerator P(Y<=1/2, X<Y)=int_0^(1/2) int_0^y f_X(x) dx dy.
    inner_y = poly_integral_0_to_y(fx)
    numerator = integrate_poly_0_to(inner_y, Q(1, 2))
    histories = [
        {"history": [x], "region": "0<=x<y<=1", "mass": p_x,
         "retained_clock_condition": "Y>X", "quantized_y_half_mass": numerator},
        {"history": [y], "region": "0<=y<x<=1", "mass": p_y,
         "retained_clock_condition": "X>Y"},
    ]
    return {"winner_mass": {x: p_x, y: p_y}, "histories": histories,
            "conditional_y_half_given_x_wins": numerator / p_x,
            "terminal_mass": p_x + p_y, "tie_mass": Q(0)}


def _integral_power(lo, hi, power):
    """Exact integral of x**power on a rational interval."""
    return (hi ** (power + 1) - lo ** (power + 1)) / Q(power + 1)


def uniform_support_competition(model, cutoff=Q(1, 2)):
    """Integrate 2x on [0,1] against a uniform clock on its declared support.

    Unlike the V1.2 routine, every integration boundary and density is read from
    the model.  The currently certified subclass is X~2x on [0,1] and a uniform
    Y on an arbitrary finite rational interval.
    """
    table = transitions(model)
    active = enabled(model, model["initial_marking"])
    if len(active) != 2:
        raise ValueError("competition requires exactly two enabled clocks")
    xs = [u for u in active if table[u]["distribution"]["family"] == "linear_2x"]
    ys = [u for u in active if table[u]["distribution"]["family"] == "uniform"]
    if len(xs) != 1 or len(ys) != 1:
        raise ValueError("certified subclass requires linear_2x versus uniform")
    x, y = xs[0], ys[0]
    xlo, xhi = map(q, table[x]["distribution"]["support"])
    ylo, yhi = map(q, table[y]["distribution"]["support"])
    if (xlo, xhi) != (0, 1) or yhi <= ylo:
        raise ValueError("UNSUPPORTED_DISTRIBUTION")
    fy = Q(1) / (yhi - ylo)
    # Integral 2x*S_Y(x), split where the uniform survival changes formula.
    p_x = Q(0)
    left_hi = min(xhi, ylo)
    if left_hi > xlo:
        p_x += _integral_power(xlo, left_hi, 1) * 2
    mid_lo, mid_hi = max(xlo, ylo), min(xhi, yhi)
    if mid_hi > mid_lo:
        p_x += fy * (yhi * 2 * _integral_power(mid_lo, mid_hi, 1)
                     - 2 * _integral_power(mid_lo, mid_hi, 2))
    p_y = Q(1) - p_x
    # Integral fY(y)*F_X(y) over y<=cutoff, with F_X clipped at 0 and 1.
    upper = min(q(cutoff), yhi)
    numerator = Q(0)
    poly_lo, poly_hi = max(ylo, Q(0)), min(upper, Q(1))
    if poly_hi > poly_lo:
        numerator += fy * _integral_power(poly_lo, poly_hi, 2)
    one_lo = max(ylo, Q(1))
    if upper > one_lo:
        numerator += fy * (upper - one_lo)
    return {
        "winner_mass": {x: p_x, y: p_y},
        "joint_y_le_cutoff_and_x_wins": numerator,
        "conditional_y_le_cutoff_given_x_wins": numerator / p_x,
        "cutoff": q(cutoff),
        "supports": {x: [xlo, xhi], y: [ylo, yhi]},
        "regions": [
            {"formula": "integral 2*x*S_Y(x) dx", "bounds": [xlo, xhi]},
            {"formula": "integral f_Y(y)*F_X(y) dy", "bounds": [ylo, upper]},
        ],
        "terminal_mass": p_x + p_y,
        "tie_mass": Q(0),
    }


def public_channel_measure(model, channel_enabled=True, metadata_only_mutant=False):
    """Execute an immediate finite network and project actual public records."""
    table = transitions(model)
    queue = deque([(dict(model["initial_marking"]), Q(1), False, [], [], [])])
    leaves = []
    while queue:
        marking, mass, fault, path, public, external = queue.popleft()
        active = enabled(model, marking)
        immediate = sorted(u for u in active if table[u].get("kind") == "immediate")
        if immediate:
            total = sum(q(table[u]["weight"]) for u in immediate)
            for tid in immediate:
                t = table[tid]
                queue.append((
                    fire(model, marking, tid), mass * q(t["weight"]) / total,
                    fault or t.get("fault", False), path + [tid],
                    public + ([t["label"]] if t.get("label") is not None else []),
                    external + ([t["external_event"]] if t.get("external_event") is not None else []),
                ))
            continue
        leaves.append({"marking": marking, "mass": mass, "fault": fault, "path": path,
                       "public_event_stream": public, "external_completion_channel": external,
                       "internal_complete": is_complete(model, marking)})
    class_mass = {name: sum((x["mass"] for x in leaves
                             if ("fault" if x["fault"] else "normal") == name), Q(0))
                  for name in ("normal", "fault")}
    conditional = {"normal": {}, "fault": {}}
    projected = []
    for leaf in leaves:
        name = "fault" if leaf["fault"] else "normal"
        external = leaf["external_completion_channel"] if channel_enabled else []
        if metadata_only_mutant:
            external = leaf["external_completion_channel"]
        observation = tuple(leaf["public_event_stream"] + [f"channel:{x}" for x in external])
        probability = leaf["mass"] / class_mass[name]
        conditional[name][observation] = conditional[name].get(observation, Q(0)) + probability
        projected.append(dict(leaf, projected_observation=list(observation)))
    prior = {"normal": Q(1, 2), "fault": Q(1, 2)}
    risk = coverage = Q(0)
    delta = q(model.get("delta", "3/20"))
    for obs in set(conditional["normal"]) | set(conditional["fault"]):
        a = prior["normal"] * conditional["normal"].get(obs, Q(0))
        b = prior["fault"] * conditional["fault"].get(obs, Q(0))
        risk += min(a, b)
        if a + b and min(a, b) / (a + b) <= delta:
            coverage += a + b
    return {"channel_enabled": channel_enabled, "raw_paths": leaves,
            "projected_paths": projected, "class_mass": class_mass,
            "conditional_measure": conditional, "bayes_error": risk,
            "reliable_coverage": coverage, "internal_state_used_in_projection": False}


def multihistory_propagation(model, resample_y_mutant=False, drop_frontier_mutant=False):
    """Exact finite history propagation for the declared U[0,1] three-clock net."""
    table = transitions(model)
    roots = [t for t in model["transitions"] if t.get("kind") == "immediate"
             and t["pre"] == model["initial_marking"]]
    if len(roots) != 2 or any(q(t["weight"]) <= 0 for t in roots):
        raise ValueError("multihistory root requires two positive immediate branches")
    branch = next(t for t in roots if t["id"] == model["history_branch"])
    total_weight = sum(q(t["weight"]) for t in roots)
    w = q(branch["weight"]) / total_weight
    threshold = q(model["quantization_boundary"])
    if not 0 <= threshold <= 1:
        raise ValueError("quantization boundary outside certified domain")
    for tid in ("x", "y", "z"):
        t = table[tid]
        if t["distribution"]["family"] != "uniform" or list(map(q, t["distribution"]["support"])) != [0, 1]:
            raise ValueError("UNSUPPORTED_DISTRIBUTION")
    branch_marking = fire(model, model["initial_marking"], branch["id"])
    if enabled(model, branch_marking) != {"x", "y"}:
        raise ValueError("history branch must really enable X and Y")
    x_middle, after_x = fire_with_middle(model, branch_marking, "x")
    if "y" not in enabled(model, x_middle) or "y" not in enabled(model, after_x):
        raise ValueError("Y is not persistent across the actual X firing")
    if enabled(model, after_x) != {"y", "z"}:
        raise ValueError("X firing must really enable persistent Y and new Z")
    if not is_complete(model, fire(model, branch_marking, "y")):
        raise ValueError("Y-first history does not reach completion")
    if not is_complete(model, fire(model, after_x, "y")):
        raise ValueError("Y-after-X history does not reach completion")
    if not is_complete(model, fire(model, after_x, "z")):
        raise ValueError("Z-after-X history does not reach completion")
    conditional = {"Y<X": Q(1, 2), "X<Y,Z<Y-X": Q(1, 6),
                   "X<Y,Y-X<Z": Q(1, 3)}
    early = {
        "Y<X": threshold - threshold ** 2 / 2,
        "X<Y,Z<Y-X": threshold ** 2 / 2 - threshold ** 3 / 3,
        "X<Y,Y-X<Z": threshold ** 2 / 2 - threshold ** 3 / 6,
    }
    labels = {"Y<X": table["y"]["label"], "X<Y,Z<Y-X": table["z"]["label"],
              "X<Y,Y-X<Z": table["y"]["label"]}
    joint = []
    histories = []
    for category, mass in conditional.items():
        early_mass = early[category]
        late_mass = mass - early_mass
        histories.append({"category": category, "parent_mass": Q(1), "conditional_mass": mass,
                          "network_mass": w * mass,
                          "y_clock_instance_before": "y#1",
                          "y_clock_instance_after_x": "y#2" if resample_y_mutant and category.startswith("X<Y") else "y#1",
                          "persistent_y": category.startswith("X<Y")})
        joint.extend([
            {"category": category, "observable_label": labels[category], "bucket": f"t<={threshold}", "conditional_mass": early_mass,
             "network_mass": w * early_mass},
            {"category": category, "observable_label": labels[category], "bucket": f"t>{threshold}", "conditional_mass": late_mass,
             "network_mass": w * late_mass},
        ])
    bypass_mass = Q(1) - w
    budget = int(model.get("path_budget", 3))
    ordered = histories
    processed = ordered[:budget]
    frontier = ordered[budget:]
    processed_mass = bypass_mass + sum((x["network_mass"] for x in processed), Q(0))
    frontier_mass = sum((x["network_mass"] for x in frontier), Q(0))
    if drop_frontier_mutant:
        frontier_mass = Q(0)
        processed_mass = Q(1)
    return {"root_history_branch_probability": w, "conditional_histories": conditional,
            "histories": histories, "quantized_joint": joint,
            "bypass": {"label": model["bypass_label"], "mass": bypass_mass},
            "processed_mass": processed_mass, "frontier_mass": frontier_mass,
            "mass_total": processed_mass + frontier_mass,
            "conditional_terminal_mass": sum(conditional.values()),
            "quantized_conditional_mass": sum(x["conditional_mass"] for x in joint),
            "integration_regions": [
                "0<=y<x<=1", "0<=x<y<=1,0<=z<y-x",
                "0<=x<y<=1,y-x<z<=1"],
            "joint_density": "1 on [0,1]^3", "budget": budget}


def class_supports(model):
    table = transitions(model)
    leaves = immediate_closure(model)
    paths = []
    for leaf in leaves:
        if is_complete(model, leaf["marking"]):
            paths.append({"class": "fault" if leaf["fault"] else "normal", "word": leaf["word"],
                          "support": [Q(0), Q(0)], "mass": leaf["mass"], "density": None})
            continue
        active = enabled(model, leaf["marking"])
        timed = [table[u] for u in active if table[u].get("kind") == "timed"]
        if len(timed) != 1:
            raise ValueError("cross-layer branch needs one timed transition")
        t = timed[0]
        after = fire(model, leaf["marking"], t["id"])
        if not is_complete(model, after):
            raise ValueError("cross-layer timed branch does not complete")
        word = leaf["word"] + ([t["label"]] if t.get("label") is not None else [])
        paths.append({"class": "fault" if leaf["fault"] else "normal", "word": word,
                      "support": list(map(q, t["interval"])), "mass": leaf["mass"],
                      "density": t["distribution"]})
    return paths


def uniform_overlap_risk(normal, fault, prior=(Q(1, 2), Q(1, 2))):
    if normal["word"] != fault["word"]:
        return Q(0)
    lo = max(normal["support"][0], fault["support"][0])
    hi = min(normal["support"][1], fault["support"][1])
    if lo >= hi:
        return Q(0)
    nd = Q(1) / (normal["support"][1] - normal["support"][0])
    fd = Q(1) / (fault["support"][1] - fault["support"][0])
    return (hi - lo) * min(prior[0] * nd, prior[1] * fd)


def cross_layer(model):
    paths = class_supports(model)
    normal = [p for p in paths if p["class"] == "normal"]
    fault = [p for p in paths if p["class"] == "fault"]
    if len(normal) != 1 or len(fault) != 1:
        raise ValueError("E1-E3 require one path per class")
    n, f = normal[0], fault[0]
    same_word = n["word"] == f["word"]
    lo, hi = max(n["support"][0], f["support"][0]), min(n["support"][1], f["support"][1])
    logical_ambiguity = same_word and lo <= hi
    risk = uniform_overlap_risk(n, f)
    alignment = {"same_discrete_structure": True, "same_fault_set": True,
                 "same_completion_markings": True,
                 "external_completion_signal": model["external_completion_signal"],
                 "probability_observation_uses_internal_state": False,
                 "status": "ALIGNED" if model["external_completion_signal"] else "THEORY_DECISION_REQUIRED"}
    return {"paths": paths, "logical_ambiguity": logical_ambiguity,
            "logical_overlap": [lo, hi] if logical_ambiguity else None,
            "bayes_error": risk, "alignment_check": alignment}


def external_signal_check(model, expose_internal=False):
    if expose_internal:
        raise ValueError("internal done/state/budget fields are forbidden observations")
    word = model["shared_prefix"]
    on = {"normal": [word, "not_complete"], "fault": [word, "complete"]}
    off = {"normal": [word], "fault": [word]}
    return {"with_external_signal": {"observations": on, "distinguishable": True},
            "without_external_signal": {"observations": off, "distinguishable": False,
                                        "status": "THEOREM_NOT_APPLICABLE"},
            "internal_state_exposed": False}


def discrete_from_network(model):
    table = transitions(model)
    leaves = immediate_closure(model)
    class_mass = {"normal": Q(0), "fault": Q(0)}
    observations = {"normal": {}, "fault": {}}
    for leaf in leaves:
        if not is_complete(model, leaf["marking"]) or len(leaf["word"]) != 1:
            raise ValueError("discrete observation path invalid")
        name = "fault" if leaf["fault"] else "normal"
        class_mass[name] += leaf["mass"]
        observations[name][leaf["word"][0]] = observations[name].get(leaf["word"][0], Q(0)) + leaf["mass"]
    for name in observations:
        observations[name] = {k: v / class_mass[name] for k, v in observations[name].items()}
    return observations


def finite_metrics(distributions, mapping, delta):
    prior = [Q(1, 2), Q(1, 2)]
    keys = sorted(set(distributions["normal"]) | set(distributions["fault"]))
    risk = coverage = Q(0)
    for key in keys:
        a = prior[0] * distributions["normal"].get(key, 0)
        b = prior[1] * distributions["fault"].get(key, 0)
        risk += min(a, b)
        if a + b and min(a, b) / (a + b) <= delta:
            coverage += a + b
    coarse = {"normal": {}, "fault": {}}
    for name in coarse:
        for key, value in distributions[name].items():
            target = mapping[key]
            coarse[name][target] = coarse[name].get(target, Q(0)) + value
    coarse_risk = coarse_coverage = Q(0)
    for key in sorted(set(coarse["normal"]) | set(coarse["fault"])):
        a = prior[0] * coarse["normal"].get(key, 0)
        b = prior[1] * coarse["fault"].get(key, 0)
        coarse_risk += min(a, b)
        if a + b and min(a, b) / (a + b) <= delta:
            coarse_coverage += a + b
    return {"fine": {"risk": risk, "coverage": coverage},
            "coarse": {"risk": coarse_risk, "coverage": coarse_coverage},
            "bayes_error_nondecreasing": coarse_risk >= risk}


def certificate_digest(payload):
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def verify_certificate(certificate, model_hash):
    if certificate.get("model_sha256") != model_hash:
        raise ValueError("certificate model hash mismatch")
    payload = certificate.get("payload")
    if certificate.get("payload_sha256") != certificate_digest(payload):
        raise ValueError("certificate payload hash mismatch")
    if payload.get("proof_type") not in {"exact_rational", "replay_witness"}:
        raise ValueError("uncertified proof type")
    return payload


def risk_decision(model_path, certificate_path=None):
    model = json.loads(Path(model_path).read_text())
    model_hash = sha256(model_path)
    if certificate_path is None:
        return {"a_P": "1", "v_P": "BOTTOM", "reason": "UNCERTIFIED_INTEGRATION"}
    certificate = json.loads(Path(certificate_path).read_text())
    payload = verify_certificate(certificate, model_hash)
    applicability = payload["applicability"]
    if applicability == "undecided":
        return {"a_P": "BOTTOM", "v_P": None, "reason": "APPLICABILITY_UNDECIDED"}
    if applicability != "positive":
        raise ValueError("unsupported applicability certificate")
    if payload.get("completion") == "violated":
        return {"a_P": "1", "v_P": "0", "reason": "CERTIFIED_COMPLETION_VIOLATION"}
    risk = payload.get("risk")
    coverage = payload.get("coverage")
    if risk and q(risk["lower"]) > q(model["decision_thresholds"]["epsilon"]):
        return {"a_P": "1", "v_P": "0", "reason": "CERTIFIED_RISK_VIOLATION"}
    if coverage and q(coverage["upper"]) < q(model["decision_thresholds"]["gamma"]):
        return {"a_P": "1", "v_P": "0", "reason": "CERTIFIED_COVERAGE_VIOLATION"}
    if (payload.get("completion") == "passed" and risk and coverage
            and q(risk["upper"]) <= q(model["decision_thresholds"]["epsilon"])
            and q(coverage["lower"]) >= q(model["decision_thresholds"]["gamma"])):
        return {"a_P": "1", "v_P": "1", "reason": "ALL_CONDITIONS_CERTIFIED"}
    return {"a_P": "1", "v_P": "BOTTOM", "reason": "INSUFFICIENT_CERTIFIED_FACTS"}
