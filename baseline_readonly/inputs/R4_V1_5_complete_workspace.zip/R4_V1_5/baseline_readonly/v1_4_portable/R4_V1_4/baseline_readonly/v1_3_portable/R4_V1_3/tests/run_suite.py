"""Frozen, fail-closed R4-V1.3 experiment runner."""
from __future__ import annotations

import csv, hashlib, json, os, shlex, subprocess, sys, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
THEORY="91aa5c1923b41a4030777d6266b466bcfdb20011a56dd7ad26f5b59fa7810e2a"
PY=sys.executable
FIELDS=["test_id","batch","model_path","model_sha256","subject_path","subject_sha256","oracle_path","oracle_sha256","command","exit_code","stdout_path","stderr_path","actual_path","oracle_result_path","comparison_path","certificate_path","runtime_limit","theory_baseline_sha256","status","blocker_reason"]

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rel(p): return str(Path(p).resolve().relative_to(ROOT))
def run(cmd,out,err,timeout=10):
    started=time.monotonic()
    with out.open("xb") as o,err.open("xb") as e:
        try: code=subprocess.run(cmd,cwd=ROOT,stdout=o,stderr=e,timeout=timeout,check=False).returncode; timed=False
        except subprocess.TimeoutExpired: code=124; timed=True
    return {"command":shlex.join(map(str,cmd)),"exit":code,"seconds":time.monotonic()-started,"timeout":timed,"stdout":rel(out),"stderr":rel(err)}

rows=[]
def verify_frozen():
    manifest=json.loads((ROOT/"frozen_manifest.json").read_text())
    for path,want in manifest.items():
        if sha(ROOT/path)!=want: raise RuntimeError(f"frozen input drift: {path}")
def base(tid,batch,model,subject,oracle="oracles/reference.py",cert=""):
    return {"test_id":tid,"batch":batch,"model_path":model or "","model_sha256":sha(ROOT/model) if model else "","subject_path":subject or "","subject_sha256":sha(ROOT/subject) if subject else "","oracle_path":oracle or "","oracle_sha256":sha(ROOT/oracle) if oracle else "","certificate_path":cert,"runtime_limit":"10s","theory_baseline_sha256":THEORY,"blocker_reason":""}

def positive(tid,batch,cmd,case,model,subject,cert=""):
    d=ROOT/"runs"/batch/tid; d.mkdir(parents=True)
    s=run(cmd,d/"subject.stdout",d/"subject.stderr")
    o=run([PY,"-B","oracles/reference.py",case],d/"oracle.stdout",d/"oracle.stderr")
    c=run([PY,"-B","tests/compare.py",s["stdout"],o["stdout"]],d/"compare.stdout",d/"compare.stderr") if s["exit"]==o["exit"]==0 else {"exit":-1,"stdout":"","stderr":""}
    status="PASS" if s["exit"]==o["exit"]==c["exit"]==0 else "FAIL"
    row=base(tid,batch,model,subject,cert=cert); row.update({"command":s["command"],"exit_code":s["exit"],"stdout_path":s["stdout"],"stderr_path":s["stderr"],"actual_path":s["stdout"],"oracle_result_path":o["stdout"],"comparison_path":c["stdout"],"status":status})
    (d/"record.json").write_text(json.dumps({"row":row,"subject":s,"oracle":o,"comparison":c},indent=2)+"\n")
    rows.append(row); print(tid,status,flush=True); return d,s,o,c

def rejection(tid,batch,cmd,model,subject,text,cert=""):
    d=ROOT/"runs"/batch/tid; d.mkdir(parents=True)
    s=run(cmd,d/"subject.stdout",d/"subject.stderr")
    content=(d/"subject.stdout").read_text(errors="replace")+(d/"subject.stderr").read_text(errors="replace")
    status="PASS" if s["exit"] not in (0,124) and text in content else "FAIL"
    row=base(tid,batch,model,subject,oracle="",cert=cert); row.update({"command":s["command"],"exit_code":s["exit"],"stdout_path":s["stdout"],"stderr_path":s["stderr"],"actual_path":s["stdout"],"oracle_result_path":"", "comparison_path":"","status":status})
    (d/"record.json").write_text(json.dumps({"row":row,"subject":s,"required_text":text},indent=2)+"\n")
    rows.append(row); print(tid,status,flush=True); return d,s

def historical(tid,cmd,model,subject,required):
    d=ROOT/"runs/history"/tid; d.mkdir(parents=True)
    s=run(cmd,d/"subject.stdout",d/"subject.stderr")
    text=(d/"subject.stdout").read_text(errors="replace")
    status="PASS" if s["exit"]==0 and all(x in text for x in required) else "FAIL"
    row=base(tid,"HISTORY",model,subject,oracle=""); row.update({"command":s["command"],"exit_code":s["exit"],"stdout_path":s["stdout"],"stderr_path":s["stderr"],"actual_path":s["stdout"],"oracle_result_path":"","comparison_path":"","status":status})
    (d/"record.json").write_text(json.dumps({"row":row,"subject":s,"historical_defect_reproduced":status=="PASS"},indent=2)+"\n")
    rows.append(row); print(tid,status,flush=True)

def alignment_case(tid,model,logic_case,prob_case):
    d=ROOT/"runs/E"/tid; d.mkdir(parents=True)
    l=run([PY,"-B","implementations/subject/logical_module.py",model],d/"logical.stdout",d/"logical.stderr")
    p=run([PY,"-B","implementations/subject/probability_module.py",model],d/"probability.stdout",d/"probability.stderr")
    lo=run([PY,"-B","oracles/reference.py",logic_case],d/"logical_oracle.stdout",d/"logical_oracle.stderr")
    po=run([PY,"-B","oracles/reference.py",prob_case],d/"probability_oracle.stdout",d/"probability_oracle.stderr")
    lc=run([PY,"-B","tests/compare.py",l["stdout"],lo["stdout"]],d/"logical_compare.stdout",d/"logical_compare.stderr")
    pc=run([PY,"-B","tests/compare.py",p["stdout"],po["stdout"]],d/"probability_compare.stdout",d/"probability_compare.stderr")
    a=run([PY,"-B","implementations/subject/alignment.py",l["stdout"],p["stdout"]],d/"alignment.stdout",d/"alignment.stderr")
    ao=run([PY,"-B","oracles/reference.py","ALIGN"],d/"alignment_oracle.stdout",d/"alignment_oracle.stderr")
    ac=run([PY,"-B","tests/compare.py",a["stdout"],ao["stdout"]],d/"alignment_compare.stdout",d/"alignment_compare.stderr")
    status="PASS" if all(x["exit"]==0 for x in (l,p,lo,po,lc,pc,a,ao,ac)) else "FAIL"
    row=base(tid,"E",model,"implementations/subject/logical_module.py"); row.update({"command":l["command"]+" && "+p["command"],"exit_code":max(l["exit"],p["exit"],a["exit"]),"stdout_path":l["stdout"],"stderr_path":l["stderr"],"actual_path":a["stdout"],"oracle_result_path":ao["stdout"],"comparison_path":ac["stdout"],"status":status})
    (d/"record.json").write_text(json.dumps({"row":row,"logical":l,"probability":p,"alignment":a},indent=2)+"\n")
    rows.append(row); print(tid,status,flush=True)

def alignment_negative(tid,model,prob_flag):
    d=ROOT/"runs/E"/tid; d.mkdir(parents=True)
    l=run([PY,"-B","implementations/subject/logical_module.py",model],d/"logical.stdout",d/"logical.stderr")
    p=run([PY,"-B","implementations/subject/probability_module.py",model,prob_flag],d/"probability.stdout",d/"probability.stderr")
    a=run([PY,"-B","implementations/subject/alignment.py",l["stdout"],p["stdout"]],d/"alignment.stdout",d/"alignment.stderr")
    data=json.loads((d/"alignment.stdout").read_text()) if a["exit"]==3 else {}
    status="PASS" if l["exit"]==p["exit"]==0 and a["exit"]==3 and data.get("status")=="THEOREM_NOT_APPLICABLE" else "FAIL"
    row=base(tid,"E",model,"implementations/subject/alignment.py",oracle=""); row.update({"command":a["command"],"exit_code":a["exit"],"stdout_path":a["stdout"],"stderr_path":a["stderr"],"actual_path":a["stdout"],"oracle_result_path":"","comparison_path":"","status":status})
    (d/"record.json").write_text(json.dumps({"row":row,"logical":l,"probability":p,"alignment":a},indent=2)+"\n")
    rows.append(row); print(tid,status,flush=True)

def mutation(tid,cmd,case,model,subject,mode="compare",target=""):
    d=ROOT/"runs/F"/tid; d.mkdir(parents=True)
    o=run([PY,"-B","oracles/reference.py",case],d/"oracle.stdout",d/"oracle.stderr") if case else {"exit":0,"stdout":"","stderr":""}
    s=run(cmd,d/"subject.stdout",d/"subject.stderr")
    detected=False; comp={"exit":-1,"stdout":"","stderr":""}
    if o["exit"]!=0: status="HARNESS_ERROR"
    else:
        if mode=="compare" and s["exit"]==0:
            comp=run([PY,"-B","tests/compare.py",s["stdout"],o["stdout"]],d/"compare.stdout",d/"compare.stderr"); detected=comp["exit"]!=0
        elif mode=="target_error": detected=s["exit"]!=0 and target in (d/"subject.stderr").read_text(errors="replace")
        elif mode=="contains": detected=s["exit"]==0 and target in (d/"subject.stdout").read_text(errors="replace")
        elif mode=="y_instance" and s["exit"]==0:
            data=json.loads((d/"subject.stdout").read_text()); detected=any(h["persistent_y"] and h["y_clock_instance_after_x"]!="y#1" for h in data["histories"])
        elif mode=="old_self_instance" and s["exit"]==0:
            data=json.loads((d/"subject.stdout").read_text()); detected=data["trace"][0]["clocks_after"]["x"]["instance"]=="x#1"
        status="MUTATION_DETECTED" if detected else "MUTATION_UNDETECTED"
    row=base(tid,"F",model,subject); row.update({"command":s["command"],"exit_code":s["exit"],"stdout_path":s["stdout"],"stderr_path":s["stderr"],"actual_path":s["stdout"],"oracle_result_path":o["stdout"],"comparison_path":comp["stdout"],"status":status})
    (d/"record.json").write_text(json.dumps({"row":row,"subject":s,"oracle":o,"comparison":comp,"mode":mode,"target":target},indent=2)+"\n")
    rows.append(row); print(tid,status,flush=True)

def main():
    verify_frozen()
    # G0 and A
    rejection("G0_MALFORMED","G0",[PY,"-B","implementations/subject/cli.py","VALIDATE","models/probability_multihistory/malformed.json"],"models/probability_multihistory/malformed.json","implementations/subject/cli.py","JSONDecodeError")
    rejection("G0_SUPPORT_MISMATCH","G0",[PY,"-B","implementations/subject/cli.py","VALIDATE","models/probability_multihistory/inconsistent_support.json"],"models/probability_multihistory/inconsistent_support.json","implementations/subject/cli.py","distribution support differs")
    positive("A1_C04","A",[PY,"-B","implementations/subject/cli.py","C04","models/c04_regression/a1_v1_1_regression.json"],"A1","models/c04_regression/a1_v1_1_regression.json","implementations/subject/cli.py")
    positive("A2_C04","A",[PY,"-B","implementations/subject/cli.py","C04","models/c04_regression/a2_true_infeasible.json"],"A2","models/c04_regression/a2_true_infeasible.json","implementations/subject/cli.py")
    positive("A_ENDPOINT","A",[PY,"-B","implementations/subject/cli.py","C04","models/c04_regression/endpoint_feasible.json"],"A_ENDPOINT","models/c04_regression/endpoint_feasible.json","implementations/subject/cli.py")
    positive("A_TRUE_TAIL","A",[PY,"-B","implementations/subject/cli.py","C04","models/c04_regression/tail_fault_after_visible.json"],"A_TAIL","models/c04_regression/tail_fault_after_visible.json","implementations/subject/cli.py")
    # B history, R04, exact certificates and attacks
    historical("B1_V12_FORGERY_REPLAY",[PY,"-B","implementations/legacy_v12/cli.py","R04_DECISION","models/r04_certificates/legal_priority_frontier.json","certificates/forged/v12_negative_out_of_range.json"],"models/r04_certificates/legal_priority_frontier.json","implementations/legacy_v12/cli.py",['"v_P": "1"','ALL_CONDITIONS_CERTIFIED'])
    positive("B2_R04_ACCOUNT","B",[PY,"-B","implementations/subject/cli.py","R04","models/r04_certificates/legal_priority_frontier.json","2"],"R04_BUDGET2","models/r04_certificates/legal_priority_frontier.json","implementations/subject/cli.py")
    positive("B3_VALID_PASS","B",[PY,"-B","implementations/certificate_verifier/cli.py","models/r04_certificates/cert_pass_network.json","certificates/valid/pass_exact_replay.json"],"CERT_PASS","models/r04_certificates/cert_pass_network.json","implementations/certificate_verifier/cli.py","certificates/valid/pass_exact_replay.json")
    positive("B3_VALID_FAIL","B",[PY,"-B","implementations/certificate_verifier/cli.py","models/r04_certificates/cert_fail_network.json","certificates/valid/risk_fail_exact_replay.json"],"CERT_FAIL","models/r04_certificates/cert_fail_network.json","implementations/certificate_verifier/cli.py","certificates/valid/risk_fail_exact_replay.json")
    attacks=[("OUT_OF_RANGE","certificates/forged/v12_negative_out_of_range.json"),("IN_RANGE_WRONG","certificates/forged/in_range_wrong_result.json"),("MODIFIED_STEP","certificates/forged/modified_intermediate.json"),("DELETED_PATH","certificates/forged/deleted_path.json"),("DUPLICATED_PATH","certificates/forged/duplicated_path.json"),("WRONG_THRESHOLD","certificates/forged/wrong_threshold.json"),("WRONG_OBSERVATION","certificates/forged/wrong_observation.json")]
    for name,cert in attacks: rejection("B_ATTACK_"+name,"B",[PY,"-B","implementations/certificate_verifier/cli.py","models/r04_certificates/cert_pass_network.json",cert],"models/r04_certificates/cert_pass_network.json","implementations/certificate_verifier/cli.py","CERTIFICATE_INVALID",cert)
    rejection("B_ATTACK_WRONG_MODEL","B",[PY,"-B","implementations/certificate_verifier/cli.py","models/r04_certificates/cert_fail_network.json","certificates/valid/pass_exact_replay.json"],"models/r04_certificates/cert_fail_network.json","implementations/certificate_verifier/cli.py","CERTIFICATE_INVALID","certificates/valid/pass_exact_replay.json")
    # C
    positive("C_R06_BASE","C",[PY,"-B","implementations/subject/cli.py","R06_BASE","models/r06_observation/legal_mixed_network.json"],"R06_BASE","models/r06_observation/legal_mixed_network.json","implementations/subject/cli.py")
    positive("C_CHANNEL_ON","C",[PY,"-B","implementations/subject/cli.py","CHANNEL","models/r06_observation/discriminative_completion_channel.json","on"],"CHANNEL_ON","models/r06_observation/discriminative_completion_channel.json","implementations/subject/cli.py")
    positive("C_CHANNEL_OFF","C",[PY,"-B","implementations/subject/cli.py","CHANNEL","models/r06_observation/discriminative_completion_channel.json","off"],"CHANNEL_OFF","models/r06_observation/discriminative_completion_channel.json","implementations/subject/cli.py")
    # D
    historical("D1_V12_WRONG_U02",[PY,"-B","implementations/legacy_v12/cli.py","NONUNIFORM","models/probability_multihistory/p03_y_uniform_0_2.json"],"models/probability_multihistory/p03_y_uniform_0_2.json","implementations/legacy_v12/cli.py",['"x": "1/3"','"conditional_y_half_given_x_wins": "1/8"'])
    for tid,model,case in [("D1_U01","models/probability_multihistory/p03_y_uniform_0_1.json","P03_U01"),("D1_U02","models/probability_multihistory/p03_y_uniform_0_2.json","P03_U02"),("D1_U032","models/probability_multihistory/p03_y_uniform_0_3_2.json","P03_U032")]: positive(tid,"D",[PY,"-B","implementations/subject/cli.py","P03",model],case,model,"implementations/subject/cli.py")
    positive("D2_BASE","D",[PY,"-B","implementations/subject/cli.py","MULTIHISTORY","models/probability_multihistory/multihistory_base.json"],"D2_BASE","models/probability_multihistory/multihistory_base.json","implementations/subject/cli.py")
    positive("D2_WEIGHT_THRESHOLD_BUDGET","D",[PY,"-B","implementations/subject/cli.py","MULTIHISTORY","models/probability_multihistory/multihistory_weight_variant.json"],"D2_VARIANT","models/probability_multihistory/multihistory_weight_variant.json","implementations/subject/cli.py")
    # E
    for tid,model,lcase,pcase in [("E1","models/cross_layer/e1_disjoint_v13.json","E1_LOGIC","E1_PROB"),("E2","models/cross_layer/e2_endpoint_v13.json","E2_LOGIC","E2_PROB"),("E3","models/cross_layer/e3_overlap_v13.json","E3_LOGIC","E3_PROB")]: alignment_case(tid,model,lcase,pcase)
    alignment_negative("E_NEG_CHANNEL","models/cross_layer/e3_overlap_v13.json","--channel-off")
    alignment_negative("E_NEG_COARSEN","models/cross_layer/e3_overlap_v13.json","--coarsen")
    # F original six
    mutation("M1_TIMESTAMP",[PY,"-B","mutants/M1_TIMESTAMP/cli.py","C04","models/c04_regression/a1_v1_1_regression.json"],"A1","models/c04_regression/a1_v1_1_regression.json","mutants/M1_TIMESTAMP/cli.py")
    mutation("M2_NO_IMMEDIATE_PRIORITY",[PY,"-B","mutants/M2_NO_IMMEDIATE_PRIORITY/cli.py","R06","models/r06_observation/legal_mixed_network.json"],"R06_BASE","models/r06_observation/legal_mixed_network.json","mutants/M2_NO_IMMEDIATE_PRIORITY/cli.py","target_error","R06 leaf must enable exactly one timed transition")
    mutation("M3_DROP_FRONTIER",[PY,"-B","mutants/M3_DROP_FRONTIER/cli.py","R04","models/r04_certificates/legal_priority_frontier.json","2"],"R04_BUDGET2","models/r04_certificates/legal_priority_frontier.json","mutants/M3_DROP_FRONTIER/cli.py")
    mutation("M4_READ_OBSERVATION_MEASURE",[PY,"-B","mutants/M4_READ_OBSERVATION_MEASURE/cli.py","R06","models/r06_observation/forbidden_hint_variant.json"],"R06_BASE","models/r06_observation/forbidden_hint_variant.json","mutants/M4_READ_OBSERVATION_MEASURE/cli.py")
    mutation("M5_KEEP_SELF_CLOCK",[PY,"-B","mutants/M5_KEEP_SELF_CLOCK/cli.py","CLOCKS","models/probability_multihistory/clock_resample_twice.json"],None,"models/probability_multihistory/clock_resample_twice.json","mutants/M5_KEEP_SELF_CLOCK/cli.py","old_self_instance")
    mutation("M6_FAKE_CERTIFIED_BOUNDS",[PY,"-B","mutants/M6_FAKE_CERTIFIED_BOUNDS/cli.py","R04","models/r04_certificates/legal_priority_frontier.json","2"],"R04_BUDGET2","models/r04_certificates/legal_priority_frontier.json","mutants/M6_FAKE_CERTIFIED_BOUNDS/cli.py")
    # new six
    mutation("M7_SHA_ONLY",[PY,"-B","mutants/M7_SHA_ONLY.py","models/r04_certificates/legal_priority_frontier.json","certificates/forged/v12_negative_out_of_range.json"],None,"models/r04_certificates/legal_priority_frontier.json","mutants/M7_SHA_ONLY.py","contains",'"v_P": "1"')
    mutation("M8_UNIT_SUPPORT",[PY,"-B","mutants/M8_UNIT_SUPPORT.py","models/probability_multihistory/p03_y_uniform_0_2.json"],"P03_U02","models/probability_multihistory/p03_y_uniform_0_2.json","mutants/M8_UNIT_SUPPORT.py")
    mutation("M9_METADATA_SIGNAL",[PY,"-B","mutants/M9_METADATA_SIGNAL.py","models/r06_observation/discriminative_completion_channel.json"],"CHANNEL_OFF","models/r06_observation/discriminative_completion_channel.json","mutants/M9_METADATA_SIGNAL.py")
    mutation("M10_HARDCODE_ALIGNMENT",[PY,"-B","mutants/M10_HARDCODE_ALIGNMENT.py","runs/E/E_NEG_COARSEN/logical.stdout","runs/E/E_NEG_COARSEN/probability.stdout"],None,"models/cross_layer/e3_overlap_v13.json","mutants/M10_HARDCODE_ALIGNMENT.py","contains",'"aligned": true')
    mutation("M11_RESAMPLE_Y",[PY,"-B","mutants/M11_RESAMPLE_Y.py","models/probability_multihistory/multihistory_base.json"],None,"models/probability_multihistory/multihistory_base.json","mutants/M11_RESAMPLE_Y.py","y_instance")
    mutation("M12_RENORMALIZE",[PY,"-B","mutants/M12_RENORMALIZE.py","models/probability_multihistory/multihistory_weight_variant.json"],"D2_VARIANT","models/probability_multihistory/multihistory_weight_variant.json","mutants/M12_RENORMALIZE.py")
    # Theory contract rows are intentionally not executed.
    for tid,status,reason in [("ALGORITHM_4_1_CONFLICT","THEORY_CONTRACT_PENDING","CURRENT_TEX_BEHAVIOR_DIFFERS_FROM_AUDIT_PROPOSED_BEHAVIOR"),("PHASE_II","WAITING_FOR_THEORY_BASELINE","NO_SIGNED_NEW_THEORY_BASELINE")]:
        row={k:"" for k in FIELDS}; row.update({"test_id":tid,"batch":"THEORY","runtime_limit":"","theory_baseline_sha256":THEORY,"status":status,"blocker_reason":reason}); rows.append(row)
    with (ROOT/"results.csv").open("x",newline="") as f: w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
    manifest={}
    for p in sorted((ROOT/"runs").rglob("*")):
        if p.is_file(): manifest[rel(p)]=sha(p)
    (ROOT/"results_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    verify_frozen()
    bad={"FAIL","MUTATION_UNDETECTED","HARNESS_ERROR"}
    return int(any(r["status"] in bad for r in rows))

if __name__=="__main__": raise SystemExit(main())
