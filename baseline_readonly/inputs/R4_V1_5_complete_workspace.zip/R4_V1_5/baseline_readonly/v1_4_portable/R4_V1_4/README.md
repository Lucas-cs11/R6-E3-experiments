# R4-V1.4 实验交付

本目录保存 D2 网络驱动联合概率传播、终止语义和真实 M11 时钟重抽样变异的独立实验实现。它不是已经丢失的历史 Linux 程序，也不是一般 LSTPN 求解器。

正式结果见 `results.csv`。45 条记录中有 31 条 PASS、13 条 `MUTATION_DETECTED` 和 1 条 `THEORY_CONTRACT_PENDING`，没有 FAIL、UNRESOLVED 或 NOT_EXECUTED。覆盖关系见 `coverage_matrix.csv`，完整裁决见 `reports/acceptance_report.md`。

最短复核命令：

```bash
cd /path/to/R4_V1_4
python3 -B tests/final_verify.py
```

脚本会重新执行新增 D2 输入扰动、真实 M11、账本篡改、C04、R04、R06、P03、E1—E3 和跨层负测。成功时末行是 `FINAL_VERIFY PASS`。

第四轮 TeX 只读副本保存在 `baseline_readonly/theory_round4.tex`，未被修改。算法 4.1 没有收到新的冻结理论接口，对应状态保持 `THEORY_CONTRACT_PENDING`。
