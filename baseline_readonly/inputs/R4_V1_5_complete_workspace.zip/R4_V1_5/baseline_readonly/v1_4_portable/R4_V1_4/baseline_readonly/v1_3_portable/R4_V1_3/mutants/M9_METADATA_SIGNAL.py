"""M9: channel-off still projects the actual completion record."""
import json,sys
sys.path.insert(0,"implementations/subject")
from engine import encode,load_model,public_channel_measure
model=load_model(sys.argv[1],probability=True)
print(json.dumps(encode(public_channel_measure(model,False,metadata_only_mutant=True)),indent=2))
