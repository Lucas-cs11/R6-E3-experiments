"""Build audit-equivalent P0 models from the V1.4 frozen baseline.

The original independent model files were not supplied.  These files implement
the exact minimal transition changes described in the independent acceptance
report and are labelled as reconstructions, not original audit artifacts.
"""

import copy
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT / "baseline_readonly/v1_4_portable/R4_V1_4/"
    "models/d2_baseline/A01_baseline.json"
)
OUTPUT = ROOT / "models/reconstructed_p0"


def transition(model, identifier):
    return next(item for item in model["transitions"] if item["id"] == identifier)


def write(name, model):
    path = OUTPUT / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(model, indent=2, sort_keys=True) + "\n", encoding="utf-8")


base = json.loads(SOURCE.read_text(encoding="utf-8"))

reset = copy.deepcopy(base)
reset["id"] = "R4V15_RECONSTRUCTED_X_BREAKS_Y_AND_RESETS_CLOCK"
x = transition(reset, "x")
x["pre"]["py"] = 1
x["post"]["py"] = 1
reset["provenance"] = {
    "kind": "reconstructed_from_independent_report",
    "missing_original_name": "x_breaks_y_enabling_and_resets_clock.json",
    "exact_described_change": "x.pre and x.post each add py:1",
}
write("x_breaks_y_enabling_and_resets_clock.reconstructed.json", reset)

third = copy.deepcopy(base)
third["id"] = "R4V15_RECONSTRUCTED_ADDITIONAL_ENABLED_IMMEDIATE_ROOT"
third["places"].extend(["seed", "alternative"])
third["initial_marking"] = {"root": 1, "seed": 1}
for identifier in ("choose_history", "choose_bypass"):
    transition(third, identifier)["pre"] = {"root": 1, "seed": 1}
third["transitions"].insert(2, {
    "id": "choose_alternative",
    "kind": "immediate",
    "weight": "4",
    "pre": {"root": 1},
    "post": {"alternative": 1},
    "interval": ["0", "0"],
    "label": "alternative",
    "fault": False,
})
third["provenance"] = {
    "kind": "reconstructed_from_independent_report",
    "missing_original_name": "additional_enabled_immediate_root.json",
    "exact_described_change": "seed token; old roots consume root+seed; new weight-4 root consumes root only",
}
write("additional_enabled_immediate_root.reconstructed.json", third)

print("generated 2 reconstructed P0 models")
