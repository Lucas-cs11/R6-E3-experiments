"""One-time generation of normative V1.3 models from preserved V1.2 inputs."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

for name in ("e1_disjoint", "e2_endpoint", "e3_overlap"):
    source = ROOT / f"models/cross_layer/{name}.json"
    model = json.loads(source.read_text())
    model["id"] += "_V13_EXTERNAL_CHANNEL"
    for transition in model["transitions"]:
        if transition.get("kind") == "timed" and transition.get("label") is not None:
            transition["external_event"] = "completed"
    target = ROOT / f"models/cross_layer/{name}_v13.json"
    target.write_text(json.dumps(model, indent=2) + "\n")

source = ROOT.parent / "R4_V1_2/extensions/models/c04_tail_fault_after_visible.json"
target = ROOT / "models/c04_regression/tail_fault_after_visible.json"
target.write_bytes(source.read_bytes())
