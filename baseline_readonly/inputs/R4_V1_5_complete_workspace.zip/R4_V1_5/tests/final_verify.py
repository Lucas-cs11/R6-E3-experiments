"""Fail-closed final verifier for the frozen V1.5 evidence."""

import hashlib
import json
import sys
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
errors = []


def sha256(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def read_json(relative):
    path = ROOT / relative
    if not path.is_file():
        errors.append(f"missing {relative}")
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"invalid JSON {relative}: {exc}")
        return {}


summary = read_json("results/v15_acceptance_summary.json")
regression = read_json("results/regression/frozen_v13_fresh_replay/regression_summary.json")
inventory = read_json("evidence/input_inventory.json")
pending = read_json("evidence/algorithm_4_1_contract_pending.json")
baseline = json.loads((ROOT / "logs/baseline_failures/summary.stdout").read_text(encoding="utf-8"))

if summary.get("status") != "PASS":
    errors.append("V1.5 acceptance summary is not PASS")
if len(summary.get("cases", [])) != 26:
    errors.append("expected 26 V1.5 case executions")
if any(not item.get("accepted") for item in summary.get("cases", [])):
    errors.append("at least one V1.5 case is not accepted")
if sum(bool(item.get("mathematical_answer_validated")) for item in summary.get("cases", [])) != 24:
    errors.append("expected 24 mathematical validations")
if summary.get("m11", {}).get("status") != "PASS":
    errors.append("M11 strong mutation did not pass")
if summary.get("m11", {}).get("normal_spec_detected_mutation") is not True:
    errors.append("M11 was not rejected by the normal semantic oracle")
if summary.get("ledger_tamper", {}).get("status") != "PASS":
    errors.append("LEDGER_TAMPER was not detected")
if any(item.get("status") != "PASS" for item in summary.get("metamorphic", [])):
    errors.append("metamorphic relation failed")
if regression.get("status") != "PASS":
    errors.append("fresh V1.3 regression is not PASS")
if baseline.get("status") != "BASELINE_P0_ERRORS_REPRODUCED":
    errors.append("old P0 failures were not reproduced")
if inventory.get("status") != "RECORDED_WITH_MISSING_INPUTS":
    errors.append("input inventory state is wrong")
if any(item.get("declared_hash_matches") is False for item in inventory.get("items", [])):
    errors.append("declared input hash mismatch")
for item in inventory.get("items", []):
    relative = item.get("relative_frozen_path")
    measured = item.get("measured_sha256")
    if relative and measured:
        path = ROOT / relative
        if not path.is_file() or sha256(path) != measured:
            errors.append(f"frozen input changed: {relative}")
if pending.get("status") != "THEORY_CONTRACT_PENDING":
    errors.append("Algorithm 4.1 pending state missing")

oracle_source = (ROOT / "oracles/independent_reference.py").read_text(encoding="utf-8")
if "from implementations" in oracle_source or "import implementations" in oracle_source:
    errors.append("oracle imports subject implementation")
for required in ("README.md", "acceptance_report.md", "unresolved_issues.md",
                 "mutations/M11_strong_clock_lifecycle.patch"):
    if not (ROOT / required).is_file():
        errors.append(f"missing {required}")

# Bind every summary row to raw command outputs, comparison, model, and ledger.
evidence_hashes = []
for case in summary.get("cases", []):
    name = case.get("case", "")
    folder = ROOT / "results/runs" / name
    subject_path = folder / "subject.json"
    oracle_path = folder / "oracle.json"
    comparison_path = folder / "comparison.json"
    subject_log = ROOT / "logs/runs" / f"{name}__subject.command.json"
    oracle_log = ROOT / "logs/runs" / f"{name}__oracle.command.json"
    required_paths = [subject_path, oracle_path, comparison_path, subject_log, oracle_log]
    if any(not path.is_file() for path in required_paths):
        errors.append(f"incomplete raw evidence for {name}")
        continue
    subject = json.loads(subject_path.read_text(encoding="utf-8"))
    comparison = json.loads(comparison_path.read_text(encoding="utf-8"))
    subject_command = json.loads(subject_log.read_text(encoding="utf-8"))
    oracle_command = json.loads(oracle_log.read_text(encoding="utf-8"))
    if subject_command.get("exit_code") != case.get("subject_exit"):
        errors.append(f"subject exit mismatch for {name}")
    if oracle_command.get("exit_code") != case.get("oracle_exit"):
        errors.append(f"oracle exit mismatch for {name}")
    if comparison.get("status") != case.get("comparison"):
        errors.append(f"comparison status mismatch for {name}")
    if comparison.get("mathematical_answer_validated", False) != case.get("mathematical_answer_validated"):
        errors.append(f"mathematical validation mismatch for {name}")
    model_path = ROOT / case.get("model", "")
    command_model_bound = any(
        str(argument).replace("\\", "/").endswith(case.get("model", ""))
        for argument in subject_command.get("argv", [])
    )
    if not model_path.is_file() or not command_model_bound:
        errors.append(f"model/command binding missing for {name}")
    if "mass_ledger" in subject:
        ledger_path = folder / "mass_ledger.json"
        if not ledger_path.is_file() or json.loads(ledger_path.read_text(encoding="utf-8")) != subject["mass_ledger"]:
            errors.append(f"mass ledger mismatch for {name}")
    for path in required_paths + ([model_path] if model_path.is_file() else []):
        evidence_hashes.append(f"{path.relative_to(ROOT)}:{sha256(path)}")

# Bind the frozen replay summary to its freshly generated result table.
fresh_csv = ROOT / "results/regression/frozen_v13_fresh_replay/fresh_results.csv"
if fresh_csv.is_file():
    with fresh_csv.open(newline="", encoding="utf-8") as stream:
        fresh_rows = {row["test_id"]: row["status"] for row in csv.DictReader(stream)}
    for test_id, check in regression.get("checks", {}).items():
        if fresh_rows.get(test_id) != check.get("actual"):
            errors.append(f"frozen regression evidence mismatch for {test_id}")
    evidence_hashes.append(f"{fresh_csv.relative_to(ROOT)}:{sha256(fresh_csv)}")
else:
    errors.append("missing fresh frozen-regression result table")

for case_name in ("P0_CLOCK_RESET_FALSE_PASS", "P0_THIRD_IMMEDIATE_FALSE_PASS"):
    folder = ROOT / "logs/baseline_failures" / case_name
    for leaf in ("subject.stdout", "oracle.stdout", "compare.stdout", "reproduction.json"):
        path = folder / leaf
        if not path.is_file():
            errors.append(f"missing baseline failure evidence {case_name}/{leaf}")
        else:
            evidence_hashes.append(f"{path.relative_to(ROOT)}:{sha256(path)}")

result = {"status": "PASS" if not errors else "FAIL", "errors": errors,
          "verified_case_count": len(summary.get("cases", [])),
          "mathematically_validated_count": sum(
              bool(item.get("mathematical_answer_validated")) for item in summary.get("cases", [])),
          "evidence_tree_sha256": hashlib.sha256(
              "\n".join(sorted(evidence_hashes)).encode("utf-8")).hexdigest()}
target = ROOT / "results/final_verification.json"
target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if not errors else 1)
