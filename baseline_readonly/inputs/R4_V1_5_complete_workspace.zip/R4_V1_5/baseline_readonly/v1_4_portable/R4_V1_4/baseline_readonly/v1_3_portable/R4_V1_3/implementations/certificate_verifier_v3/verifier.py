"""Independent replay verifier for finite exact rational risk certificates."""
from __future__ import annotations

import hashlib
import json
from collections import deque
from fractions import Fraction as F
from pathlib import Path


def q(value):
    return value if isinstance(value, F) else F(str(value))


def enc(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): enc(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [enc(v) for v in value]
    return value


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _enabled(model, marking):
    return [t for t in model["transitions"]
            if all(marking.get(p, 0) >= n for p, n in t["pre"].items())]


def _fire(marking, transition):
    out = dict(marking)
    for p, n in transition["pre"].items():
        out[p] -= n
        if not out[p]:
            del out[p]
    for p, n in transition["post"].items():
        out[p] = out.get(p, 0) + n
    return out


def _marking_key(marking):
    return tuple(sorted(marking.items()))


def validate_model(model):
    required={"id","places","transitions","initial_marking","completion","decision_prior","delta","decision_thresholds","observation_contract"}
    if required-set(model): raise ValueError("model fields missing")
    if not isinstance(model["id"],str) or not model["id"]: raise ValueError("invalid model id")
    if "expected" in model or "observation_measure" in model: raise ValueError("forbidden answer field")
    places=model["places"]
    if not isinstance(places,list) or not places or len(set(places))!=len(places): raise ValueError("invalid places")
    place_set=set(places);ids=set()
    def marking(value):
        if not isinstance(value,dict) or not set(value)<=place_set: raise ValueError("invalid marking places")
        if any(type(n) is not int or n<=0 for n in value.values()): raise ValueError("invalid marking tokens")
    marking(model["initial_marking"])
    if not isinstance(model["completion"],list) or not model["completion"]: raise ValueError("invalid completion")
    for m in model["completion"]: marking(m)
    for t in model["transitions"]:
        if not isinstance(t.get("id"),str) or not t["id"]: raise ValueError("invalid transition id")
        if t.get("id") in ids: raise ValueError("duplicate transition")
        ids.add(t.get("id"))
        if t.get("label") is not None and not isinstance(t["label"],str): raise ValueError("invalid label type")
        if type(t.get("fault",False)) is not bool: raise ValueError("invalid fault type")
        if not isinstance(t.get("pre"),dict) or not isinstance(t.get("post"),dict): raise ValueError("invalid arcs")
        if not set(t["pre"])<=place_set or not set(t["post"])<=place_set: raise ValueError("unknown place")
        if any(type(n) is not int or n<=0 for n in [*t["pre"].values(),*t["post"].values()]): raise ValueError("invalid arc weight")
        if t.get("kind")!="immediate" or list(map(q,t.get("interval",[])))!=[0,0] or q(t.get("weight",0))<=0: raise ValueError("certificate subclass requires positive immediate transitions")
    priors=model["decision_prior"]
    if not isinstance(priors,list) or len(priors)!=2: raise ValueError("prior must contain exactly two values")
    priors=list(map(q,priors))
    if any(x<0 for x in priors) or sum(priors)!=1: raise ValueError("prior invalid")
    for name in ("delta",):
        if not 0<=q(model[name])<=1: raise ValueError(f"{name} outside [0,1]")
    if set(model["decision_thresholds"])!={"epsilon","gamma"}: raise ValueError("threshold fields invalid")
    for name,value in model["decision_thresholds"].items():
        if not 0<=q(value)<=1: raise ValueError(f"{name} outside [0,1]")


def validate_acyclic(model):
    visiting=set();done=set();count=0
    completion={_marking_key(m) for m in model["completion"]}
    def visit(mark):
        nonlocal count
        key=_marking_key(mark)
        if key in completion:return
        if key in visiting:raise ValueError("instantaneous cycle not certifiable")
        if key in done:return
        count+=1
        if count>10000:raise ValueError("state budget exceeded")
        visiting.add(key)
        for t in _enabled(model,mark):visit(_fire(mark,t))
        visiting.remove(key);done.add(key)
    visit(model["initial_marking"])


def replay_model(model):
    validate_model(model)
    validate_acyclic(model)
    if model.get("observation_contract") != "public_label_sequence":
        raise ValueError("unsupported observation contract")
    queue = deque([(dict(model["initial_marking"]), F(1), False, [], [])])
    leaves = []
    while queue:
        marking, mass, fault, path, word = queue.popleft()
        if marking in model["completion"]:
            leaves.append({"path": path, "class": "fault" if fault else "normal",
                           "observation": word, "joint_mass": mass})
            continue
        active = _enabled(model, marking)
        if not active: raise ValueError("non-completing terminal path")
        total = sum(q(t["weight"]) for t in active)
        for t in sorted(active, key=lambda x: x["id"]):
            queue.append((_fire(marking, t), mass * q(t["weight"]) / total,
                          fault or t.get("fault", False), path + [t["id"]],
                          word + ([t["label"]] if t.get("label") is not None else [])))
    class_mass = {c: sum((x["joint_mass"] for x in leaves if x["class"] == c), F(0))
                  for c in ("normal", "fault")}
    if any(v <= 0 for v in class_mass.values()) or sum(class_mass.values()) != 1:
        raise ValueError("class mass invalid")
    conditional = {"normal": {}, "fault": {}}
    for row in leaves:
        key = json.dumps(row["observation"], separators=(",", ":"))
        conditional[row["class"]][key] = conditional[row["class"]].get(key, F(0)) + row["joint_mass"] / class_mass[row["class"]]
    priors = dict(zip(("normal", "fault"), map(q, model["decision_prior"])))
    risk = coverage = F(0)
    delta = q(model["delta"])
    contributions = []
    for obs in sorted(set(conditional["normal"]) | set(conditional["fault"])):
        n = priors["normal"] * conditional["normal"].get(obs, F(0))
        f = priors["fault"] * conditional["fault"].get(obs, F(0))
        error, total = min(n, f), n + f
        posterior = error / total
        risk += error
        reliable = posterior <= delta
        if reliable:
            coverage += total
        contributions.append({"observation": json.loads(obs), "normal_weighted": n,
                              "fault_weighted": f, "error": error,
                              "posterior_error": posterior, "reliable": reliable})
    return {"paths": leaves, "class_mass": class_mass, "conditional": conditional,
            "contributions": contributions, "risk": risk, "coverage": coverage,
            "completion": "passed", "total_mass": sum(x["joint_mass"] for x in leaves)}


def verify(model_path, certificate_path):
    model = json.loads(Path(model_path).read_text())
    cert = json.loads(Path(certificate_path).read_text())
    if cert.get("schema") != "r4v13-exact-replay-v1":
        raise ValueError("CERTIFICATE_INVALID: schema")
    if cert.get("model_sha256") != sha(model_path):
        raise ValueError("CERTIFICATE_INVALID: model binding")
    if cert.get("thresholds") != model.get("decision_thresholds"):
        raise ValueError("CERTIFICATE_INVALID: threshold binding")
    if cert.get("observation_contract") != model.get("observation_contract"):
        raise ValueError("CERTIFICATE_INVALID: observation binding")
    replay = replay_model(model)
    expected_proof = enc(replay)
    if cert.get("proof") != expected_proof:
        raise ValueError("CERTIFICATE_INVALID: replay proof mismatch")
    risk, coverage = replay["risk"], replay["coverage"]
    if not (0 <= risk <= 1 and 0 <= coverage <= 1):
        raise ValueError("CERTIFICATE_INVALID: probability range")
    epsilon = q(model["decision_thresholds"]["epsilon"])
    gamma = q(model["decision_thresholds"]["gamma"])
    decision = "0" if risk > epsilon or coverage < gamma else "1"
    reason = "CERTIFIED_CONSTRAINT_VIOLATION" if decision == "0" else "ALL_CONDITIONS_CERTIFIED"
    return {"certificate_status": "VALID", "a_P": "1", "v_P": decision,
            "reason": reason, "recomputed": replay}
