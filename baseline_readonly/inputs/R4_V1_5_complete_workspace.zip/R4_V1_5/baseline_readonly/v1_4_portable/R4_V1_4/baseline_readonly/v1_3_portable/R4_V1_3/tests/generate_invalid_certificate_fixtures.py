import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for name in ("zero_class_mass","negative_density"):
 p=ROOT/f"models/r04_certificates/{name}.json";m=json.loads(p.read_text())
 c={"schema":"r4v13-exact-replay-v1","model_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),
    "thresholds":m["decision_thresholds"],"observation_contract":m["observation_contract"],"proof":{}}
 (ROOT/f"certificates/forged/{name}.json").write_text(json.dumps(c,indent=2)+"\n")
