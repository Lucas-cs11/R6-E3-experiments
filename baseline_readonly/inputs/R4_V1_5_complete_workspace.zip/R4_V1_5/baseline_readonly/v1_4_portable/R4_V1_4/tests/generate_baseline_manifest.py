"""Record mandatory baseline metadata, including the declared missing helper."""

import hashlib
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "baseline_manifest.json"
if OUTPUT.exists():
    raise FileExistsError(OUTPUT)

entries = [
    ROOT / "baseline_readonly" / "R4_V1_2_independent_acceptance_20261120.md",
    ROOT / "baseline_readonly" / "v1_3_independent_acceptance_20261120.md",
    ROOT / "baseline_readonly" / "R4_V1_3_portable_evidence.zip",
    ROOT / "baseline_readonly" / "R4_V1_3_complete_workspace.zip",
    ROOT / "baseline_readonly" / "theory_round4.tex",
    ROOT / "baseline_readonly" / "v1_4_full_instruction.md",
]
records = []
for path in entries:
    info = path.stat()
    records.append({
        "path": str(path.resolve()),
        "bytes": info.st_size,
        "mtime": datetime.fromtimestamp(info.st_mtime).astimezone().isoformat(),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "present": True,
    })
records.append({
    "path": "/Users/lucas/Downloads/results1005/R4_V1_3_独立扰动检查.py",
    "expected_sha256": "abcf664a93b2f6cabe0065b08226dfde3121fcacd929dc156fe774710c9f54c6",
    "present": False,
    "handling": "absence declared; four documented perturbations independently reimplemented and reproduced",
})
OUTPUT.write_text(json.dumps({"inputs": records}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(OUTPUT)
