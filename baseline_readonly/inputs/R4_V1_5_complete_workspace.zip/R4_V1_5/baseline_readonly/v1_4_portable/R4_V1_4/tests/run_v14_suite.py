"""Run the formal R4-V1.4 D2/M11 suite and consolidate regressions."""

from __future__ import annotations

import csv
import hashlib
import json
import shlex
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable
RESULTS = ROOT / "results.csv"
if RESULTS.exists():
    raise FileExistsError(f"refusing to overwrite {RESULTS}")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def execute(command, directory, stem, timeout=30):
    directory.mkdir(parents=True, exist_ok=False) if not directory.exists() else None
    completed = subprocess.run(
        command, cwd=ROOT, capture_output=True, text=True, timeout=timeout, check=False
    )
    (directory / f"{stem}.stdout").write_text(completed.stdout, encoding="utf-8")
    (directory / f"{stem}.stderr").write_text(completed.stderr, encoding="utf-8")
    (directory / f"{stem}.exit").write_text(f"{completed.returncode}\n", encoding="utf-8")
    (directory / f"{stem}.command.json").write_text(
        json.dumps({
            "command": command,
            "command_shell_display": shlex.join(command),
            "cwd": str(ROOT),
            "timeout_seconds": timeout,
            "exit_code": completed.returncode,
        }, indent=2) + "\n",
        encoding="utf-8",
    )
    return completed, directory / f"{stem}.stdout"


rows = []
models = [
    ("D2_A01_BASE", "models/d2_baseline/A01_baseline.json", "D2-A,D2-B,D2-C"),
    ("D2_A02_ACTUAL_LABEL", "models/d2_adversarial/A02_actual_label.json", "D2-A,NEG-1"),
    ("D2_A03_FORGED_METADATA", "models/d2_adversarial/A03_forged_metadata.json", "D2-A,NEG-2"),
    ("D2_A04_SILENT_LABEL", "models/d2_adversarial/A04_silent_bypass.json", "D2-A"),
    ("D2_A05_EQUAL_WEIGHT", "models/d2_adversarial/A05_equal_root_weight.json", "D2-A,D2-C"),
    ("D2_B02_DEADLOCK", "models/d2_adversarial/B02_bypass_deadlock.json", "D2-B,NEG-3"),
    ("D2_B03_DEADLOCK_LABEL", "models/d2_adversarial/B03_deadlock_new_label.json", "D2-B"),
    ("D2_B04_LOW_BUDGET", "models/d2_adversarial/B04_low_budget.json", "D2-B,D2-C,NEG-4"),
    ("D2_B05_COMPLETION_CHANGED", "models/d2_adversarial/B05_completion_changed.json", "D2-B"),
    ("D2_C_BOUNDARY_THIRD", "models/d2_adversarial/C_boundary_one_third.json", "D2-C"),
]
for test_id, relative_model, coverage in models:
    evidence = ROOT / "runs" / "d2" / test_id
    model = ROOT / relative_model
    subject, subject_path = execute(
        [PY, "-B", "implementations/subject/cli.py", relative_model], evidence, "subject"
    )
    oracle, oracle_path = execute(
        [PY, "-B", "oracles/d2_reference.py", relative_model], evidence, "oracle"
    )
    comparison, comparison_path = execute(
        [PY, "-B", "tests/compare_d2.py", str(subject_path), str(oracle_path)], evidence, "compare"
    )
    status = "PASS" if subject.returncode == oracle.returncode == comparison.returncode == 0 else "FAIL"
    rows.append({
        "test_id": test_id,
        "batch": "D2",
        "status": status,
        "model_path": relative_model,
        "model_sha256": sha(model),
        "subject_path": "implementations/subject/cli.py",
        "subject_sha256": sha(ROOT / "implementations/subject/engine.py"),
        "oracle_path": "oracles/d2_reference.py",
        "oracle_sha256": sha(ROOT / "oracles/d2_reference.py"),
        "evidence_path": str(evidence.relative_to(ROOT)),
        "coverage": coverage,
        "reason": "network-derived observation, termination, exact buckets and full mass ledger agree",
    })

unsupported_model = "models/clock_mutants/first_completion_at_x.json"
unsupported_evidence = ROOT / "runs" / "d2" / "D2_UNSUPPORTED_FIRST_COMPLETION_AT_X"
unsupported_subject, _ = execute(
    [PY, "-B", "implementations/subject/cli.py", unsupported_model],
    unsupported_evidence, "subject"
)
unsupported_oracle, _ = execute(
    [PY, "-B", "oracles/d2_reference.py", unsupported_model],
    unsupported_evidence, "oracle"
)
unsupported_status = "PASS" if (
    unsupported_subject.returncode == 2
    and unsupported_oracle.returncode != 0
    and "first completion occurs at intermediate X firing" in unsupported_subject.stderr
    and "first completion occurs at intermediate X firing" in unsupported_oracle.stderr
) else "FAIL"
rows.append({
    "test_id": "D2_UNSUPPORTED_FIRST_COMPLETION_AT_X",
    "batch": "D2",
    "status": unsupported_status,
    "model_path": unsupported_model,
    "model_sha256": sha(ROOT / unsupported_model),
    "subject_path": "implementations/subject/cli.py",
    "subject_sha256": sha(ROOT / "implementations/subject/engine.py"),
    "oracle_path": "oracles/d2_reference.py",
    "oracle_sha256": sha(ROOT / "oracles/d2_reference.py"),
    "evidence_path": str(unsupported_evidence.relative_to(ROOT)),
    "coverage": "D2-B,fail-closed",
    "reason": "model completing at intermediate X is rejected instead of silently continuing past first completion",
})

m11_evidence = ROOT / "runs" / "m11" / "M11_REAL_RESAMPLE"
mutant, mutant_path = execute(
    [PY, "-B", "implementations/mutant_m11/cli.py", "models/d2_baseline/A01_baseline.json"],
    m11_evidence, "mutant"
)
m11_oracle, m11_oracle_path = execute(
    [PY, "-B", "oracles/m11_reference.py", "models/d2_baseline/A01_baseline.json"],
    m11_evidence, "oracle"
)
m11_compare, _ = execute(
    [PY, "-B", "tests/compare_m11.py", str(mutant_path), str(m11_oracle_path)],
    m11_evidence, "compare"
)
m11_status = "MUTATION_DETECTED" if mutant.returncode == m11_oracle.returncode == m11_compare.returncode == 0 else "FAIL"
rows.append({
    "test_id": "M11_REAL_RESAMPLE",
    "batch": "M11",
    "status": m11_status,
    "model_path": "models/d2_baseline/A01_baseline.json",
    "model_sha256": sha(ROOT / "models/d2_baseline/A01_baseline.json"),
    "subject_path": "implementations/mutant_m11/engine.py",
    "subject_sha256": sha(ROOT / "implementations/mutant_m11/engine.py"),
    "oracle_path": "oracles/m11_reference.py",
    "oracle_sha256": sha(ROOT / "oracles/m11_reference.py"),
    "evidence_path": str(m11_evidence.relative_to(ROOT)),
    "coverage": "M11,NEG-5",
    "reason": "self-consistent real reset semantics detected by four-variable oracle and positive T>1 tail",
})

tamper_evidence = ROOT / "runs" / "m11" / "LEDGER_TAMPER"
tampered, tampered_path = execute(
    [PY, "-B", "mutations/M_LEDGER_TAMPER.py", "models/d2_baseline/A01_baseline.json"],
    tamper_evidence, "mutant"
)
tamper_oracle, tamper_oracle_path = execute(
    [PY, "-B", "oracles/d2_reference.py", "models/d2_baseline/A01_baseline.json"],
    tamper_evidence, "oracle"
)
tamper_compare, tamper_compare_path = execute(
    [PY, "-B", "tests/compare_d2.py", str(tampered_path), str(tamper_oracle_path)],
    tamper_evidence, "compare"
)
tamper_text = tamper_compare_path.read_text(encoding="utf-8")
tamper_status = "MUTATION_DETECTED" if (
    tampered.returncode == tamper_oracle.returncode == 0
    and tamper_compare.returncode == 1
    and "category_bucket_frontier_balance" in tamper_text
) else "FAIL"
rows.append({
    "test_id": "LEDGER_TAMPER",
    "batch": "NEGATIVE",
    "status": tamper_status,
    "model_path": "models/d2_baseline/A01_baseline.json",
    "model_sha256": sha(ROOT / "models/d2_baseline/A01_baseline.json"),
    "subject_path": "mutations/M_LEDGER_TAMPER.py",
    "subject_sha256": sha(ROOT / "mutations/M_LEDGER_TAMPER.py"),
    "oracle_path": "oracles/d2_reference.py",
    "oracle_sha256": sha(ROOT / "oracles/d2_reference.py"),
    "evidence_path": str(tamper_evidence.relative_to(ROOT)),
    "coverage": "NEG-6",
    "reason": "post-hoc category-only tampering rejected by category/bucket/frontier invariant",
})

regression_summary_path = ROOT / "runs/regression/frozen_v13_replay/regression_summary.json"
regression = json.loads(regression_summary_path.read_text(encoding="utf-8"))
for test_id, item in sorted(regression["checks"].items()):
    rows.append({
        "test_id": f"REG_{test_id}",
        "batch": "REGRESSION",
        "status": item["actual"] if item["pass"] else "FAIL",
        "model_path": "baseline_readonly/v1_3_portable/R4_V1_3",
        "model_sha256": "see fresh_results.csv",
        "subject_path": "baseline_readonly/v1_3_portable/R4_V1_3",
        "subject_sha256": "see fresh_results.csv",
        "oracle_path": "baseline_readonly/v1_3_portable/R4_V1_3/oracles/reference.py",
        "oracle_sha256": sha(ROOT / "baseline_readonly/v1_3_portable/R4_V1_3/oracles/reference.py"),
        "evidence_path": "runs/regression/frozen_v13_replay",
        "coverage": "required-regression",
        "reason": "fresh isolated replay of unchanged accepted V1.3 component",
    })

baseline_reproduction = json.loads(
    (ROOT / "runs/baseline_failures/reproduce_v13.stdout").read_text(encoding="utf-8")
)
rows.extend([
    {
        "test_id": "BASELINE_FOUR_FAILURES",
        "batch": "HISTORY",
        "status": "PASS" if baseline_reproduction.get("status") == "BASELINE_FAILURES_REPRODUCED" else "FAIL",
        "model_path": "baseline_readonly/v1_3_portable/R4_V1_3",
        "model_sha256": sha(ROOT / "baseline_readonly/R4_V1_3_portable_evidence.zip"),
        "subject_path": "tests/reproduce_v13_failures.py",
        "subject_sha256": sha(ROOT / "tests/reproduce_v13_failures.py"),
        "oracle_path": "R4_V1_3 independent audit descriptions",
        "oracle_sha256": sha(ROOT / "baseline_readonly/v1_3_independent_acceptance_20261120.md"),
        "evidence_path": "runs/baseline_failures",
        "coverage": "historical-reproduction",
        "reason": "all four old failures reproduced before V1.4 implementation",
    },
    {
        "test_id": "ALGORITHM_4_1_CONFLICT",
        "batch": "THEORY",
        "status": "THEORY_CONTRACT_PENDING",
        "model_path": "baseline_readonly/theory_round4.tex",
        "model_sha256": sha(ROOT / "baseline_readonly/theory_round4.tex"),
        "subject_path": "",
        "subject_sha256": "",
        "oracle_path": "",
        "oracle_sha256": "",
        "evidence_path": "baseline_readonly/v1_3_portable/R4_V1_3/runs/THEORY/ALGORITHM_4_1_CONFLICT",
        "coverage": "theory-contract",
        "reason": "no new signed frozen theory interface received",
    },
])

fields = ["test_id", "batch", "status", "model_path", "model_sha256", "subject_path",
          "subject_sha256", "oracle_path", "oracle_sha256", "evidence_path", "coverage", "reason"]
with RESULTS.open("x", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)

hard_failures = [row["test_id"] for row in rows if row["status"] in {"FAIL", "UNRESOLVED", "NOT_EXECUTED"}]
print(json.dumps({"rows": len(rows), "hard_failures": hard_failures,
                  "status": "PASS" if not hard_failures else "NOT_CLOSED"}, indent=2))
raise SystemExit(0 if not hard_failures else 1)
