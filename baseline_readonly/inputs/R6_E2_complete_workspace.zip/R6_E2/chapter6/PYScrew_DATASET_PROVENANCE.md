# R1-3 Phase 0 — PyScrew Dataset Provenance

**Dataset:** *Screw Driving Dataset - s04_variations-in-assembly-conditions-2*
(West, N., & Deuse, J., RIF/IPS TU Dortmund).

- **Zenodo DOI:** 10.5281/zenodo.16031381 (v1.2.3)
- **Primary DOI:** 10.5281/zenodo.14729547 (dataset collection record)
- **Paper:** West, N., & Deuse, J., *A Comparative Study of Machine Learning
  Approaches for Anomaly Detection in Industrial Screw Driving Data*, HICSS 2024,
  DOI 10.24251/HICSS.2024.126
- **License:** CC BY 4.0
- **Download date:** 2026-08-22, from the Zenodo record.

## Physical-system provenance

Physical industrial screw-driving data from an **automatic screwing station**
(CS351 controller, EV motor control unit assembly): thermoplastic housing
components joined with Delta PT 40x12 thermoplastic-optimized screws at a
target torque of 1.4 Nm (window 1.2-1.6 Nm). Each workpiece is uniquely
identified by a **14-digit data-matrix code (DMC)**; every operation records
the full torque/angle/time series at 833.33 Hz plus a four-stage tightening
protocol (Finding, Thread forming, Pre-tightening, Final tightening at 1.4 Nm).

## Recording structure

- 5000 JSON files, each one **complete physical operation**
  (5000 operations, 2500 unique workpieces x 2 screw positions left/right).
- 25 experimental classes (1 control + 24 physical error classes); each class
  200 operations = 100 unique workpieces x 2.
- `labels.csv`: run_id, file_name, class_value, workpiece_id (DMC),
  workpiece_date, workpiece_usage, workpiece_result (OK/NOK),
  workpiece_location (left/right), scenario_condition (normal/faulty),
  scenario_exception.

## Files and checksums (immutable raw)

| file | bytes | SHA-256 | MD5 (Zenodo) |
|---|---|---:|---|
| `raw/s04_variations-in-assembly-conditions-2.zip` | 61107763 | `a85bb4593c8732159cf0e7b5c239594e06d86dcf68e7ee744641ee16cd025a77` | `7f580205863743c2b083cbeebfa61117` |
| `raw/unpacked/labels.csv` | 536941 | `f56685c18f67a1aba464e460e0e74327a881d0f68fbfc779981bd1b4b62d2c2b` | — |
| `raw/unpacked/json/` | 5000 JSON | derived from verified archive | |

The zip MD5 matches the Zenodo-recorded checksum (7f580205863743c2b083cbeebfa61117),
confirming download integrity. All analysis lives in `r1_3/`; `raw/` is immutable.

## Key Phase-0 structural observations

1. **One JSON = one independent physical execution.** Unlike the CONTEXT
   continuous streams, no segmentation is needed; each record carries its own
   per-execution identity (run_id, id code, cycle, date).
2. **Native four-stage controller program** (`prg name = SMW_4step`): Finding,
   Thread forming, Pre-tightening, Tightening 1.4. Completion = the final
   tightening step reporting OK; first-entry by construction (each execution
   emits at most one completion, as the station runs the steps once in order).
3. **scenario_condition vs workpiece_result are separate variables**: faulty-
   condition operations complete OK in bulk (e.g. 96/100, 100/100, 110/110)
   and normal-condition operations occasionally fail NOK (e.g. 101: 9/100) —
   fault present does not force failure and fault absent does not guarantee
   success. This is the structure required for non-trivial task-completion
   diagnosis.
4. Class label = documented physical manipulation (thread deformation, surface
   modification, material change, process-parameter change), category-1
   ground truth independent of any observation mapping.
