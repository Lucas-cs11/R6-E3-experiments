"""One-time construction of V1.4 frozen model variants.

This script is a build-time provenance tool.  Test runners only read the files
it creates and never invoke it automatically.
"""

import copy
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT / "baseline_readonly" / "v1_3_portable" / "R4_V1_3" /
    "models" / "probability_multihistory" / "multihistory_base.json"
)
BASE_DIR = ROOT / "models" / "d2_baseline"
ADV_DIR = ROOT / "models" / "d2_adversarial"


def transition(model, identifier):
    return next(item for item in model["transitions"] if item["id"] == identifier)


def write(name, model, folder=ADV_DIR):
    path = folder / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(model, indent=2, sort_keys=True) + "\n", encoding="utf-8")


base = json.loads(SOURCE.read_text(encoding="utf-8"))
base["id"] = "R4V14_D2_A01_BASE"
write("A01_baseline.json", base, BASE_DIR)

actual_label = copy.deepcopy(base)
actual_label["id"] = "R4V14_D2_A02_ACTUAL_LABEL"
transition(actual_label, "choose_bypass")["label"] = "ACTUAL_NEW_PUBLIC_LABEL"
write("A02_actual_label.json", actual_label)

forged_metadata = copy.deepcopy(base)
forged_metadata["id"] = "R4V14_D2_A03_FORGED_METADATA"
forged_metadata["bypass_label"] = "FORGED_METADATA_ONLY"
write("A03_forged_metadata.json", forged_metadata)

silent = copy.deepcopy(base)
silent["id"] = "R4V14_D2_A04_SILENT_BYPASS"
transition(silent, "choose_bypass")["label"] = None
write("A04_silent_bypass.json", silent)

equal_weight = copy.deepcopy(base)
equal_weight["id"] = "R4V14_D2_A05_EQUAL_ROOT_WEIGHT"
transition(equal_weight, "choose_history")["weight"] = "1"
transition(equal_weight, "choose_bypass")["weight"] = "1"
write("A05_equal_root_weight.json", equal_weight)

deadlock = copy.deepcopy(base)
deadlock["id"] = "R4V14_D2_B02_UNFINISHED_DEADLOCK"
transition(deadlock, "choose_bypass")["post"] = {"hist": 1}
write("B02_bypass_deadlock.json", deadlock)

deadlock_label = copy.deepcopy(deadlock)
deadlock_label["id"] = "R4V14_D2_B03_DEADLOCK_NEW_LABEL"
transition(deadlock_label, "choose_bypass")["label"] = "DEADLOCK_PUBLIC_LABEL"
write("B03_deadlock_new_label.json", deadlock_label)

low_budget = copy.deepcopy(base)
low_budget["id"] = "R4V14_D2_B04_LOW_BUDGET"
low_budget["path_budget"] = 1
write("B04_low_budget.json", low_budget)

completion_changed = copy.deepcopy(deadlock)
completion_changed["id"] = "R4V14_D2_B05_COMPLETION_CHANGED"
completion_changed["completion"] = [
    {"hist": 1},
    {"done_y": 1, "px": 1},
    {"done_y": 1, "after_x": 1, "pz": 1},
    {"done_z": 1, "py": 1},
]
write("B05_completion_changed.json", completion_changed)

boundary_third = copy.deepcopy(base)
boundary_third["id"] = "R4V14_D2_C_BOUNDARY_ONE_THIRD"
boundary_third["quantization_boundary"] = "1/3"
write("C_boundary_one_third.json", boundary_third)

print("generated 10 frozen D2 models")
