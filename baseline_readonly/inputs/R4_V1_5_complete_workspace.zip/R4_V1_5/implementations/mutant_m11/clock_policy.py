"""M11: wrongly reset persistent Y after X in the real propagation path."""


def adjust_clock_sets(fired, persistent, newly_enabled):
    mutations = []
    if fired == "x" and "y" in persistent:
        persistent.remove("y")
        newly_enabled.add("y")
        mutations.append({
            "mutation": "FORCE_RESET_STRUCTURALLY_PERSISTENT_Y",
            "retired_instance": "y#1",
            "new_instance": "y#2",
        })
    return persistent, newly_enabled, mutations
