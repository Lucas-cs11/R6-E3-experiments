"""Independent immediate-tree enumeration and public projection reference."""
import json,sys
from fractions import Fraction as F

model=json.load(open(sys.argv[1])); channel=sys.argv[2]=="on"
def enabled(mark): return [t for t in model["transitions"] if all(mark.get(p,0)>=n for p,n in t["pre"].items())]
def fire(mark,t):
 out=dict(mark)
 for p,n in t["pre"].items():
  out[p]-=n
  if not out[p]: del out[p]
 for p,n in t["post"].items(): out[p]=out.get(p,0)+n
 return out
stack=[(model["initial_marking"],F(1),False,[],[])]
leaves=[]
while stack:
 mark,mass,fault,public,external=stack.pop(); active=enabled(mark)
 if not active: leaves.append((mass,"fault" if fault else "normal",tuple(public+(["channel:"+x for x in external] if channel else [])))); continue
 total=sum(F(t["weight"]) for t in active)
 for t in active: stack.append((fire(mark,t),mass*F(t["weight"])/total,fault or t.get("fault",False),public+([t["label"]] if t.get("label") else []),external+([t["external_event"]] if t.get("external_event") else [])))
cm={c:sum((m for m,k,_ in leaves if k==c),F(0)) for c in ("normal","fault")}
dist={c:{} for c in cm}
for m,c,o in leaves: dist[c][o]=dist[c].get(o,F(0))+m/cm[c]
risk=coverage=F(0); delta=F(model.get("delta","3/20"))
for o in set(dist["normal"])|set(dist["fault"]):
 a=F(1,2)*dist["normal"].get(o,F(0));b=F(1,2)*dist["fault"].get(o,F(0));risk+=min(a,b)
 if min(a,b)/(a+b)<=delta: coverage+=a+b
print(json.dumps({"channel_enabled":channel,"bayes_error":str(risk),"reliable_coverage":str(coverage),"internal_state_used_in_projection":False},indent=2))
