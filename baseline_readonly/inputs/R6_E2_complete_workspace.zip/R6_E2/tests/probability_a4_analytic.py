#!/usr/bin/env python3
"""Exact Bayes error and reliable coverage for the frozen continuous example."""

import csv
import json
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results/probability_a4_21points.csv'


def exact(a4):
    a4 = F(a4)
    if not 3 <= a4 <= 4:
        raise ValueError('a4 outside frozen interval [3,4]')
    common_width = 4 - a4
    # On common support, prior-weighted densities are 1/4 and 1/(2(5-a4)).
    # Neither posterior reaches 17/20 there; outside it the posterior is certain.
    return common_width / 4, 1 - common_width * (F(1, 4) + 1 / (2 * (5 - a4)))


def main():
    rows = []
    for k in range(21):
        a4 = 3 + F(k, 20)
        pe, gamma = exact(a4)
        rows.append({'k': k, 'a4': str(a4), 'Pe': str(pe), 'Gamma': str(gamma),
                     'status': 'EXACT_ANALYTIC',
                     'note': 'Continuous observation; pi0=pi1=1/2; delta=3/20; frozen TeX densities'})
    with OUT.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(json.dumps({'rows': len(rows), 'anchors': [rows[0], rows[10], rows[20]]}, indent=2))


if __name__ == '__main__':
    main()
