🥷 # R4-V1.5 实验整改与独立复验

本工程只处理 Petri 网模型、时钟生命周期、概率传播、终止分类和实验验收。没有修改论文、TeX、数学定义或证明，也没有尝试恢复 Linux 历史源码。

## 已支持的受限子类

- 有限、加权输入弧的小型 PN，标识和变迁由 JSON 真实结构给出。
- 初始状态是一组互斥即时变迁的局部竞争，按完整使能集与真实权重归一化。
- 历史分支使能 `x` 和 `y`；`x` 后使能 `y` 和 `z`。三个定时器均为独立 `U[0,1]`。
- 依据 `M`、`M_minus`、`M_next` 的真实使能交集决定持续时钟与重抽样时钟。
- 完成、未完成死锁和未解析前沿的质量分开记账。

并发非冲突即时变迁、即时链、非 `U[0,1]` 分布、不同的定时竞争拓扑和本次定时变迁自循环不在当前求解器的认证域内。这些输入在计算前返回 `UNSUPPORTED_MODEL` 或 `ORACLE_UNSUPPORTED`，不输出确定性概率。

## 执行

```bash
python3 tests/run_v15_acceptance.py
python3 tests/run_frozen_v13_regression.py
python3 tests/final_verify.py
```

主程序入口是 `implementations/subject/cli.py MODEL.json`，独立参考入口是 `oracles/independent_reference.py MODEL.json`。两者没有共用使能、发射、`M_minus` 或时钟生命周期代码。

`tests/run_v15_acceptance.py` 为防止覆盖证据，在 `results/runs/` 非空时会拒绝重跑。便携包的 `reproduce.sh` 会在新解压目录中清理随包证据副本后再运行，不影响封版工程。

## 证据导航

- `logs/baseline_failures/`：旧 V1.4 主程序和旧 oracle 对两份报告重建反例的假 PASS。
- `results/runs/`：本轮每个模型的 subject、oracle、逐字段比较和 `mass_ledger.json`。
- `results/m11_strong_mutation.json`：正常时钟与真实重抽样变异的概率、时间桶与尾质量差异。
- `results/regression/frozen_v13_fresh_replay/`：C04、R04、R06、P03、E1—E3 和 M1—M10、M12 的本轮隔离重跑。
- `evidence/input_inventory.json`：输入实测哈希、可读状态和缺失项。
- `acceptance_report.md`：G0—G8 裁决。
