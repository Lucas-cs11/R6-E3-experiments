"""Real M11 mutant: reset persistent Y after X and re-integrate all regions."""

from __future__ import annotations

import json
from fractions import Fraction as F
from pathlib import Path


def q(value):
    return value if isinstance(value, F) else F(str(value))


def encode(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(item) for item in value]
    return value


def load_model(path):
    model = json.loads(Path(path).read_text(encoding="utf-8"))
    items = {item["id"]: item for item in model["transitions"]}
    if not {"choose_history", "choose_bypass", "x", "y", "z"} <= set(items):
        raise ValueError("UNSUPPORTED M11 model")
    for identifier in ("x", "y", "z"):
        distribution = items[identifier].get("distribution", {})
        if distribution.get("family") != "uniform" or list(map(q, distribution.get("support", []))) != [0, 1]:
            raise ValueError("UNSUPPORTED: M11 exact mutant requires U[0,1]")
    return model


def _table(model):
    return {item["id"]: item for item in model["transitions"]}


def _enabled(model, marking):
    return {
        item["id"]
        for item in model["transitions"]
        if all(marking.get(place, 0) >= count for place, count in item["pre"].items())
    }


def _fire(model, marking, identifier):
    if identifier not in _enabled(model, marking):
        raise ValueError(f"mutant cannot fire {identifier}")
    item = _table(model)[identifier]
    after = dict(marking)
    for place, count in item["pre"].items():
        after[place] -= count
        if after[place] == 0:
            del after[place]
    for place, count in item["post"].items():
        after[place] = after.get(place, 0) + count
    return after


def _termination(model, marking):
    if marking in model["completion"]:
        return "completed_first"
    return "unresolved_frontier" if _enabled(model, marking) else "unfinished_deadlock"


def _word(items, path):
    return [items[name]["label"] for name in path if items[name].get("label") is not None]


def _representative_clock_execution():
    """Execute one rational witness through the actual wrong clock update."""
    clocks = {
        "x": {"instance": "x#1", "sample": F(1, 4), "age": F(0)},
        "y": {"instance": "y#1", "sample": F(3, 4), "age": F(0)},
    }
    log = [{"event": "sample_initial", "clocks": encode(clocks)}]
    x_delay = clocks["x"]["sample"]
    clocks["y"]["age"] += x_delay
    log.append({
        "event": "fire_x",
        "time": x_delay,
        "old_y_instance": clocks["y"]["instance"],
        "old_y_sample": clocks["y"]["sample"],
        "old_y_age": clocks["y"]["age"],
    })
    # The mutation is here: a still-enabled y#1 is discarded and sampled again.
    clocks["y"] = {"instance": "y#2", "sample": F(2, 3), "age": F(0)}
    clocks["z"] = {"instance": "z#1", "sample": F(1, 3), "age": F(0)}
    winner = min(("y", "z"), key=lambda name: clocks[name]["sample"])
    completion_time = x_delay + clocks[winner]["sample"]
    log.append({
        "event": "mutant_reset_persistent_y",
        "discarded_instance": "y#1",
        "new_y": encode(clocks["y"]),
        "new_z": encode(clocks["z"]),
    })
    log.append({
        "event": f"fire_{winner}",
        "winner_instance": clocks[winner]["instance"],
        "completion_time": completion_time,
    })
    return log


def propagate_mutant(model):
    items = _table(model)
    if model["initial_marking"] in model["completion"]:
        raise ValueError("UNSUPPORTED: initial marking is already complete")
    roots = [items["choose_history"], items["choose_bypass"]]
    normalizer = sum((q(item["weight"]) for item in roots), F(0))
    history_weight = q(items["choose_history"]["weight"]) / normalizer
    bypass_weight = q(items["choose_bypass"]["weight"]) / normalizer
    boundary = q(model["quantization_boundary"])
    if not 0 <= boundary <= 1:
        raise ValueError("UNSUPPORTED boundary")

    totals = {"Y<X": F(1, 2), "X<Y,Z<Y'": F(1, 4), "X<Y,Y'<Z": F(1, 4)}
    resampled_early = boundary**2 / 2 - boundary**3 / 3 + boundary**4 / 24
    early = {
        "Y<X": boundary - boundary**2 / 2,
        "X<Y,Z<Y'": resampled_early,
        "X<Y,Y'<Z": resampled_early,
    }
    paths = {
        "Y<X": ["choose_history", "y"],
        "X<Y,Z<Y'": ["choose_history", "x", "z"],
        "X<Y,Y'<Z": ["choose_history", "x", "y"],
    }
    history_start = _fire(model, model["initial_marking"], "choose_history")
    if history_start in model["completion"]:
        raise ValueError("UNSUPPORTED: history root completes before timed competition")
    after_x = _fire(model, history_start, "x")
    if after_x in model["completion"]:
        raise ValueError("UNSUPPORTED: first completion occurs at intermediate X firing")
    end_markings = {
        "Y<X": _fire(model, history_start, "y"),
        "X<Y,Z<Y'": _fire(model, after_x, "z"),
        "X<Y,Y'<Z": _fire(model, after_x, "y"),
    }
    bypass_marking = _fire(model, model["initial_marking"], "choose_bypass")
    bypass_termination = _termination(model, bypass_marking)
    termination_mass = {
        "completed_first": F(0),
        "unfinished_deadlock": F(0),
        "unresolved_frontier": F(0),
    }
    termination_mass[bypass_termination] += bypass_weight
    histories = []
    buckets = []
    for category, conditional_mass in totals.items():
        termination = _termination(model, end_markings[category])
        termination_mass[termination] += history_weight * conditional_mass
        histories.append({
            "category": category,
            "conditional_mass": conditional_mass,
            "network_mass": history_weight * conditional_mass,
            "public_word": _word(items, paths[category]),
            "successor_marking": end_markings[category],
            "termination": termination,
            "clock_instances": (
                {"before_x": {"y": "y#1"}, "after_x": {"y": "y#2", "z": "z#1"},
                 "y_was_erroneously_resampled": True}
                if category.startswith("X<Y")
                else {"before_x": {"y": "y#1"}, "after_x": None,
                      "y_was_erroneously_resampled": False}
            ),
        })
        for bucket, part in (
            (f"t<={boundary}", early[category]),
            (f"t>{boundary}", conditional_mass - early[category]),
        ):
            buckets.append({
                "category": category,
                "bucket": bucket,
                "conditional_mass": part,
                "network_mass": history_weight * part,
                "public_word": _word(items, paths[category]),
            })
    bypass_word = _word(items, ["choose_bypass"])
    return {
        "mutation": "M11_REAL_RESAMPLE_PERSISTENT_Y_AFTER_X",
        "mutation_site": "clock_update_after_x",
        "root_history_mass": history_weight,
        "bypass": {"mass": bypass_weight, "public_word": bypass_word,
                   "successor_marking": bypass_marking, "termination": bypass_termination},
        "histories": histories,
        "quantized_joint": buckets,
        "termination_mass": termination_mass,
        "mass_total": sum(termination_mass.values(), F(0)),
        "strong_discriminator": {
            "event": "X<old_Y and X+min(Y_prime,Z)>1",
            "conditional_T_gt_1": F(1, 12),
            "network_T_gt_1": history_weight * F(1, 12),
            "correct_persistent_semantics": F(0),
        },
        "representative_clock_execution": _representative_clock_execution(),
        "integration_regions": {
            "Y<X": "0<=y<x<=1",
            "X<Y,Z<Y'": "0<=x<y<=1, 0<=z<y'<=1",
            "X<Y,Y'<Z": "0<=x<y<=1, 0<=y'<z<=1",
        },
    }
