"""M7: deliberately reuse the V1.2 SHA-only certificate decision."""
import json,sys
sys.path.insert(0,"implementations/legacy_v12")
from engine import encode,risk_decision
print(json.dumps(encode(risk_decision(sys.argv[1],sys.argv[2])),indent=2))
