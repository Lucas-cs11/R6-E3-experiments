"""Run the two reconstructed P0 models through frozen V1.4 code."""

import json
import shlex
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
V14 = ROOT / "baseline_readonly/v1_4_portable/R4_V1_4"
LOG_ROOT = ROOT / "logs/baseline_failures"
CASES = [
    (
        "P0_CLOCK_RESET_FALSE_PASS",
        ROOT / "models/reconstructed_p0/x_breaks_y_enabling_and_resets_clock.reconstructed.json",
        {"Y<X": "1/2", "X<Y,Z<Y'": "1/4", "X<Y,Y'<Z": "1/4"},
    ),
    (
        "P0_THIRD_IMMEDIATE_FALSE_PASS",
        ROOT / "models/reconstructed_p0/additional_enabled_immediate_root.reconstructed.json",
        {"choose_history": "3/8", "choose_bypass": "1/8", "choose_alternative": "1/2"},
    ),
]


def run(command, cwd, directory, stem):
    completed = subprocess.run(
        command, cwd=cwd, capture_output=True, text=True, timeout=30, check=False
    )
    (directory / f"{stem}.stdout").write_text(completed.stdout, encoding="utf-8")
    (directory / f"{stem}.stderr").write_text(completed.stderr, encoding="utf-8")
    (directory / f"{stem}.exit").write_text(f"{completed.returncode}\n", encoding="utf-8")
    (directory / f"{stem}.command.json").write_text(json.dumps({
        "command": command,
        "command_shell_display": shlex.join(map(str, command)),
        "cwd": str(cwd),
        "exit_code": completed.returncode,
        "timeout_seconds": 30,
    }, indent=2) + "\n", encoding="utf-8")
    return completed


summary = {}
for case_id, model, correct_reference in CASES:
    directory = LOG_ROOT / case_id
    if directory.exists():
        raise FileExistsError(directory)
    directory.mkdir(parents=True)
    subject = run(
        [sys.executable, "-B", "implementations/subject/cli.py", str(model)],
        V14, directory, "subject",
    )
    oracle = run(
        [sys.executable, "-B", "oracles/d2_reference.py", str(model)],
        V14, directory, "oracle",
    )
    comparison = run(
        [sys.executable, "-B", "tests/compare_d2.py",
         str(directory / "subject.stdout"), str(directory / "oracle.stdout")],
        V14, directory, "compare",
    )
    actual = json.loads(subject.stdout) if subject.returncode == 0 else {}
    if case_id == "P0_CLOCK_RESET_FALSE_PASS":
        observed = {item["category"]: item["conditional_mass"] for item in actual.get("histories", [])}
        wrong_deterministic = observed == {
            "Y<X": "1/2", "X<Y,Z<Y-X": "1/6", "X<Y,Y-X<Z": "1/3"
        }
    else:
        observed = {
            actual.get("root", {}).get("history_transition"): actual.get("root", {}).get("history_mass"),
            actual.get("root", {}).get("bypass_transition"): actual.get("root", {}).get("bypass_mass"),
        }
        wrong_deterministic = observed == {"choose_history": "3/4", "choose_bypass": "1/4"}
    reproduced = (
        subject.returncode == 0
        and oracle.returncode == 0
        and comparison.returncode == 0
        and wrong_deterministic
    )
    record = {
        "status": "OLD_ERROR_REPRODUCED" if reproduced else "REPRODUCTION_INCOMPLETE",
        "model": str(model),
        "model_provenance": "reconstructed_from_independent_report; original audit file missing",
        "old_subject_observed": observed,
        "independent_report_reference": correct_reference,
        "old_comparator_status": "FALSE_PASS" if comparison.returncode == 0 else "REJECTED",
    }
    (directory / "reproduction.json").write_text(
        json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    summary[case_id] = record

output = {
    "status": "BASELINE_P0_ERRORS_REPRODUCED"
    if all(item["status"] == "OLD_ERROR_REPRODUCED" for item in summary.values())
    else "BASELINE_REPRODUCTION_INCOMPLETE",
    "cases": summary,
}
print(json.dumps(output, indent=2, sort_keys=True))
raise SystemExit(0 if output["status"] == "BASELINE_P0_ERRORS_REPRODUCED" else 1)
