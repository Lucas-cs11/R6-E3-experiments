"""CLI for the real R4-V1.4 M11 semantic mutant."""

import json
import sys

from engine import encode, load_model, propagate_mutant


if len(sys.argv) != 2:
    raise SystemExit("usage: cli.py MODEL.json")
try:
    print(json.dumps(encode(propagate_mutant(load_model(sys.argv[1]))), indent=2, sort_keys=True))
except Exception as exc:
    print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
    raise SystemExit(2)
