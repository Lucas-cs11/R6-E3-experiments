# 变更记录

## D2 网络传播

旧文件 `R4_V1_3/implementations/subject_v5/engine.py` 的 SHA-256 为 `b1824f762ed23fd45997157d4e036d842116ddfabcaf9fa7962c1c747e89366a`。旧函数从顶层 `bypass_label` 读取旁路观测，也没有输出旁路终止类别。

新文件 `implementations/subject/engine.py` 的 SHA-256 为 `595c3a2999d729e309a8a8a9ecce71e5fa2daaea846b6f280b6d3ae2488c1c26`。它从实际根变迁生成公开词，从后继标识、完成集合和使能关系生成终止类别，并把类别、桶、终止和前沿放入同一质量账本。

独立参考为 `oracles/d2_reference.py`，SHA-256 `27280e6e66bdf22eeb77c39ca98bc6cfbf76ce8864f76fc134efa86314dec762`。该程序自行遍历标识并在原始随机变量区域积分，不导入被测实现。总质量由终止分区求和形成，不使用预填常数。

## M11 真实时钟变异

旧文件 `R4_V1_3/mutants/M11_RESAMPLE_Y.py` 的 SHA-256 为 `e194ce3fb70c27fd2dfadbfacde7d6a020987576c3f6a10b13ea855b7423e7ec`。它先执行正确程序，再覆盖类别质量和时钟编号，时间桶仍是旧值。

新文件 `implementations/mutant_m11/engine.py` 的 SHA-256 为 `2618c3cc9fc593cef3dde598c8eaf5b4474ea7385120a38e5e40152b1757342b`。变异发生在 `clock_update_after_x`：旧 `y#1` 被丢弃，新建 `y#2` 和 `z#1`，随后重新计算全部类别、桶、终止标识和 `T>1` 尾部。独立四变量积分在 `oracles/m11_reference.py`，SHA-256 `7b9c7a093c89c1590f372793ea5426dafbb5819721e4892cc9fcdb6890b2b470`。

完整统一补丁保存在 `mutations/M11_REAL_RESAMPLE.patch`。账本字段篡改另存为 `mutations/M_LEDGER_TAMPER.py`，只用于证明一致性检查能发现事后改数，未被当作 M11。

## 输入和测试

`models/d2_baseline/` 与 `models/d2_adversarial/` 保存十个冻结模型。每个变体只改变报告要求的标号、元数据、根权重、旁路后继、完成声明、预算或量化边界。

`tests/reproduce_v13_failures.py` 在修改前复现四项旧问题。`tests/compare_d2.py` 检查被测输出、独立 oracle、类别桶和前沿对账。`tests/compare_m11.py` 先确认变异自身守恒，再用语义参考检出错误。

V1.3 隔离回放留下四次失败尝试。前两次分别暴露旧清单入口和预存运行目录，第三次暴露预存结果表，第四次表明 V1.3 发布核验器依赖不由正式套件生成的补验目录。最终采用新鲜正式套件结果和 V1.4 自己的幂等验收器，没有删除这些失败记录。

交付前深度复核发现首版 V1.4 M11 仍固定填写完成质量。该批结果和日志保存在 `runs/history/precheck_v1/`。当前版本由变异器和独立 oracle 分别执行标识发射与终止分类，正式结果在修正后重新生成。
