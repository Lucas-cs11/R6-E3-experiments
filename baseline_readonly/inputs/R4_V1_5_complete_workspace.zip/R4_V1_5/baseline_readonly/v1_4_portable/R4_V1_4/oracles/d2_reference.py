"""Independent exact reference for the bounded D2 family.

The oracle performs its own marking traversal and evaluates the three disjoint
integration regions directly.  It does not import the subject implementation.
"""

from __future__ import annotations

import json
import sys
from fractions import Fraction
from pathlib import Path


R = Fraction
CATEGORIES = ("Y<X", "X<Y,Z<Y-X", "X<Y,Y-X<Z")


def rat(value) -> R:
    return R(str(value))


def serial(value):
    if isinstance(value, R):
        return str(value)
    if isinstance(value, dict):
        return {str(key): serial(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(item) for item in value]
    return value


def table(model):
    return {item["id"]: item for item in model["transitions"]}


def can_fire(model, marking):
    return {
        item["id"]
        for item in model["transitions"]
        if all(marking.get(place, 0) >= count for place, count in item["pre"].items())
    }


def step(model, marking, identifier):
    item = table(model)[identifier]
    if identifier not in can_fire(model, marking):
        raise ValueError(f"oracle cannot fire {identifier}")
    after = dict(marking)
    for place, count in item["pre"].items():
        after[place] -= count
        if not after[place]:
            del after[place]
    for place, count in item["post"].items():
        after[place] = after.get(place, 0) + count
    return after


def finish_type(model, marking):
    if marking in model["completion"]:
        return "completed_first"
    return "unresolved_frontier" if can_fire(model, marking) else "unfinished_deadlock"


def word(items, path):
    return [items[name]["label"] for name in path if items[name].get("label") is not None]


def solve(model):
    items = table(model)
    if model["initial_marking"] in model["completion"]:
        raise ValueError("oracle: initial marking is already complete")
    roots = [
        item for item in model["transitions"]
        if item.get("kind") == "immediate" and item["pre"] == model["initial_marking"]
    ]
    history = next(item for item in roots if item["id"] == model["history_branch"])
    bypass = next(item for item in roots if item["id"] != history["id"])
    normalizer = sum((rat(item["weight"]) for item in roots), R(0))
    w_history = rat(history["weight"]) / normalizer
    w_bypass = rat(bypass["weight"]) / normalizer
    start = step(model, model["initial_marking"], history["id"])
    if start in model["completion"]:
        raise ValueError("oracle: history root completes before timed competition")
    after_x = step(model, start, "x")
    if after_x in model["completion"]:
        raise ValueError("oracle: first completion occurs at intermediate X firing")
    paths = {
        "Y<X": [history["id"], "y"],
        "X<Y,Z<Y-X": [history["id"], "x", "z"],
        "X<Y,Y-X<Z": [history["id"], "x", "y"],
    }
    end = {
        "Y<X": step(model, start, "y"),
        "X<Y,Z<Y-X": step(model, after_x, "z"),
        "X<Y,Y-X<Z": step(model, after_x, "y"),
    }
    conditional = {"Y<X": R(1, 2), "X<Y,Z<Y-X": R(1, 6), "X<Y,Y-X<Z": R(1, 3)}
    boundary = rat(model["quantization_boundary"])
    if not 0 <= boundary <= 1:
        raise ValueError("oracle boundary outside [0,1]")
    below = {
        "Y<X": boundary - boundary * boundary / 2,
        "X<Y,Z<Y-X": boundary * boundary / 2 - boundary**3 / 3,
        "X<Y,Y-X<Z": boundary * boundary / 2 - boundary**3 / 6,
    }
    budget = int(model.get("path_budget", 3))
    terminal = {
        "completed_first": R(0),
        "unfinished_deadlock": R(0),
        "other_resolved": R(0),
        "unresolved_frontier": R(0),
    }
    bypass_marking = step(model, model["initial_marking"], bypass["id"])
    bypass_type = finish_type(model, bypass_marking)
    terminal[bypass_type] += w_bypass
    histories = []
    buckets = []
    for position, category in enumerate(CATEGORIES):
        resolved = position < budget
        kind = finish_type(model, end[category]) if resolved else "unresolved_frontier"
        mass = w_history * conditional[category]
        terminal[kind] += mass
        histories.append({
            "category": category,
            "conditional_mass": conditional[category],
            "network_mass": mass,
            "path": paths[category],
            "successor_marking": end[category],
            "public_word": word(items, paths[category]),
            "termination": kind,
            "resolved": resolved,
        })
        if resolved:
            for name, part in (
                (f"t<={boundary}", below[category]),
                (f"t>{boundary}", conditional[category] - below[category]),
            ):
                buckets.append({
                    "category": category,
                    "bucket": name,
                    "conditional_mass": part,
                    "network_mass": w_history * part,
                    "public_word": word(items, paths[category]),
                    "termination": kind,
                })
    frontier = terminal["unresolved_frontier"]
    processed = sum(
        (mass for kind, mass in terminal.items() if kind != "unresolved_frontier"), R(0)
    )
    total_mass = sum(terminal.values(), R(0))
    return {
        "root": {
            "history_transition": history["id"],
            "history_mass": w_history,
            "bypass_transition": bypass["id"],
            "bypass_mass": w_bypass,
        },
        "bypass": {
            "path": [bypass["id"]],
            "successor_marking": bypass_marking,
            "public_word": word(items, [bypass["id"]]),
            "mass": w_bypass,
            "termination": bypass_type,
            "resolved": bypass_type != "unresolved_frontier",
        },
        "histories": histories,
        "quantized_joint": buckets,
        "termination_mass": terminal,
        "processed_mass": processed,
        "frontier_mass": frontier,
        "mass_total": total_mass,
    }


if len(sys.argv) != 2:
    raise SystemExit("usage: d2_reference.py MODEL.json")
model = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
print(json.dumps(serial(solve(model)), indent=2, sort_keys=True))
