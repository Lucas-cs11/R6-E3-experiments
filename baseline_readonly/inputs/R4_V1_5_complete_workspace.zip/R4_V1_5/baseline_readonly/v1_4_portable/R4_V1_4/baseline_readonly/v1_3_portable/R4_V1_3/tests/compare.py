"""Fail-closed subset comparator for rich subject outputs."""
import json
import sys


def check(actual, expected, path="$"):
    if isinstance(expected, dict):
        if not isinstance(actual, dict): raise AssertionError(f"{path}: expected object")
        for key, value in expected.items():
            if key not in actual: raise AssertionError(f"{path}: missing {key}")
            check(actual[key], value, f"{path}.{key}")
    elif isinstance(expected, list):
        if actual != expected: raise AssertionError(f"{path}: {actual!r} != {expected!r}")
    elif actual != expected:
        raise AssertionError(f"{path}: {actual!r} != {expected!r}")


actual=json.load(open(sys.argv[1]))
expected=json.load(open(sys.argv[2]))
check(actual,expected)
print(json.dumps({"comparison":"PASS","checked":expected},sort_keys=True))
