"""Compare subject D2 output with the independent reference and invariants."""

from __future__ import annotations

import json
import sys
from fractions import Fraction as F
from pathlib import Path


if len(sys.argv) != 3:
    raise SystemExit("usage: compare_d2.py SUBJECT.json ORACLE.json")
subject = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
oracle = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
errors = []


def check(name, actual, expected):
    if actual != expected:
        errors.append({"assertion": name, "actual": actual, "expected": expected})


check("root", subject["root"], oracle["root"])
for field in ("path", "successor_marking", "public_word", "mass", "termination", "resolved"):
    check(f"bypass.{field}", subject["bypass"][field], oracle["bypass"][field])

subject_histories = {
    item["category"]: {key: item[key] for key in (
        "category", "conditional_mass", "network_mass", "path", "successor_marking",
        "public_word", "termination", "resolved"
    )}
    for item in subject["histories"]
}
oracle_histories = {item["category"]: item for item in oracle["histories"]}
check("histories", subject_histories, oracle_histories)
check("quantized_joint", subject["quantized_joint"], oracle["quantized_joint"])
for field in ("termination_mass", "processed_mass", "frontier_mass", "mass_total"):
    check(field, subject[field], oracle[field])

bucket_sums: dict[str, F] = {}
for item in subject["quantized_joint"]:
    bucket_sums[item["category"]] = bucket_sums.get(item["category"], F(0)) + F(item["conditional_mass"])
for history in subject["histories"]:
    category = history["category"]
    resolved_bucket_mass = bucket_sums.get(category, F(0))
    frontier_part = F(0) if history["resolved"] else F(history["conditional_mass"])
    if resolved_bucket_mass + frontier_part != F(history["conditional_mass"]):
        errors.append({
            "assertion": f"category_bucket_frontier_balance:{category}",
            "category_mass": history["conditional_mass"],
            "bucket_mass": str(resolved_bucket_mass),
            "frontier_part": str(frontier_part),
        })

terminal_total = sum((F(value) for value in subject["termination_mass"].values()), F(0))
if terminal_total != F(1):
    errors.append({"assertion": "termination_partition", "actual": str(terminal_total), "expected": "1"})
if F(subject["processed_mass"]) + F(subject["frontier_mass"]) != F(1):
    errors.append({"assertion": "processed_plus_frontier", "actual": subject["mass_total"], "expected": "1"})

result = {
    "status": "PASS" if not errors else "FAIL",
    "assertions": 10 + len(subject["histories"]),
    "errors": errors,
}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if not errors else 1)
