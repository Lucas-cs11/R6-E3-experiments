"""Execute V1.5 cases and retain every command, result, ledger, and verdict."""

from __future__ import annotations

import json
import subprocess
import sys
from fractions import Fraction
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable
RUNS = ROOT / "results/runs"
LOGS = ROOT / "logs/runs"


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def invoke(label, argv, cwd=ROOT):
    proc = subprocess.run(argv, cwd=cwd, text=True, capture_output=True, timeout=180)
    record = {
        "label": label,
        "argv": [str(item) for item in argv],
        "cwd": str(cwd),
        "exit_code": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }
    write_json(LOGS / f"{label}.command.json", record)
    return proc


def parsed(proc):
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        return {"status": "INVALID_PROCESS_OUTPUT", "reason": str(exc), "raw": proc.stdout}


def case_name(model):
    return f"{model.parent.name}__{model.stem}"


def run_case(model, mutant=False, expected_rejection=False):
    name = case_name(model) + ("__mutant_m11" if mutant else "")
    folder = RUNS / name
    folder.mkdir(parents=True, exist_ok=True)
    subject_cli = ROOT / ("implementations/mutant_m11/cli.py" if mutant else "implementations/subject/cli.py")
    oracle_args = [PYTHON, str(ROOT / "oracles/independent_reference.py"), str(model)]
    if mutant:
        oracle_args.append("--mutant-reset-y")
    subject_proc = invoke(f"{name}__subject", [PYTHON, str(subject_cli), str(model)])
    oracle_proc = invoke(f"{name}__oracle", oracle_args)
    subject = parsed(subject_proc)
    oracle = parsed(oracle_proc)
    write_json(folder / "subject.json", subject)
    write_json(folder / "oracle.json", oracle)
    if "mass_ledger" in subject:
        write_json(folder / "mass_ledger.json", subject["mass_ledger"])
    structure = {
        "subject_status": subject.get("status"),
        "oracle_status": oracle.get("status"),
        "subject_x_fire_semantics": subject.get("x_fire_semantics"),
        "oracle_x_fire_semantics": oracle.get("x_fire_semantics"),
        "oracle_reference_equations": oracle.get("reference_equations_selected_by_lifecycle"),
    }
    write_json(folder / "structure_and_equations.json", structure)

    invalid = (subject.get("status") == "INVALID_MODEL"
               and oracle.get("status") == "ORACLE_INVALID")
    if expected_rejection and invalid:
        compare = {
            "status": "INPUT_REJECTION_CONFIRMED",
            "mathematical_answer_validated": False,
            "subject_exit_code": subject_proc.returncode,
            "oracle_exit_code": oracle_proc.returncode,
            "reason": "both implementations rejected prohibited pre-filled expected data",
        }
        compare_exit = 0
    else:
        compare_proc = invoke(
            f"{name}__compare",
            [PYTHON, str(ROOT / "tests/compare_subject_oracle.py"),
             str(folder / "subject.json"), str(folder / "oracle.json")],
        )
        compare = parsed(compare_proc)
        compare_exit = compare_proc.returncode
    write_json(folder / "comparison.json", compare)
    status = compare.get("status")
    if status == "PASS":
        exits_valid = subject_proc.returncode == 0 and oracle_proc.returncode == 0
    elif status == "DOMAIN_REJECTION_CONFIRMED":
        exits_valid = subject_proc.returncode == 3 and oracle_proc.returncode == 4
    elif status == "INPUT_REJECTION_CONFIRMED":
        exits_valid = (subject_proc.returncode == 2 and oracle_proc.returncode == 2
                       and "expected" in subject.get("reason", "").lower()
                       and "expected" in oracle.get("reason", "").lower())
    else:
        exits_valid = False
    accepted = status in {
        "PASS", "DOMAIN_REJECTION_CONFIRMED", "INPUT_REJECTION_CONFIRMED"
    } and compare_exit == 0 and exits_valid
    return {
        "case": name,
        "model": str(model.relative_to(ROOT)),
        "mutant": mutant,
        "subject_exit": subject_proc.returncode,
        "oracle_exit": oracle_proc.returncode,
        "comparison": compare.get("status"),
        "mathematical_answer_validated": compare.get("mathematical_answer_validated", False),
        "accepted": accepted,
    }, subject, oracle


def probabilities(output):
    return {item["category"]: item["conditional_mass"] for item in output["histories"]}


def roots(output):
    return {item["transition"]: item["probability"] for item in output["root_competition"]}


def metamorphic(outputs):
    base = outputs["regression__A01_baseline"]
    third = outputs["b4__three_root_base"]
    tests = []

    def add(identifier, condition, evidence):
        tests.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    add("unrelated_token_preserves_probability",
        probabilities(base) == probabilities(outputs["a4__unrelated_token_invariant"]),
        {"base": probabilities(base), "transformed": probabilities(outputs["a4__unrelated_token_invariant"])})
    add("place_rename_preserves_probability",
        probabilities(base) == probabilities(outputs["b4__place_rename_invariant"]),
        {"base": probabilities(base), "transformed": probabilities(outputs["b4__place_rename_invariant"])})
    add("scaled_root_weights_preserve_ratio",
        roots(base) == roots(outputs["b4__two_root_weights_scaled"]),
        {"base": roots(base), "transformed": roots(outputs["b4__two_root_weights_scaled"])})
    add("third_weight_changes_competition",
        roots(third) != roots(outputs["b4__third_weight_eight"]),
        {"base": roots(third), "transformed": roots(outputs["b4__third_weight_eight"])})
    add("third_disable_changes_enabled_set",
        set(roots(outputs["b4__third_disabled"])) == {"choose_history", "choose_bypass"},
        {"transformed": roots(outputs["b4__third_disabled"])})
    old_alt = next(item for item in third["root_competition"] if item["transition"] == "choose_alternative")
    new_alt = next(item for item in outputs["b4__alternative_label_and_completion"]["root_competition"]
                   if item["transition"] == "choose_alternative")
    add("real_label_changes_observation", old_alt["public_word"] != new_alt["public_word"],
        {"base": old_alt["public_word"], "transformed": new_alt["public_word"]})
    add("completion_marking_changes_termination", old_alt["termination"] != new_alt["termination"],
        {"base": old_alt["termination"], "transformed": new_alt["termination"]})
    add("unrelated_token_preserves_three_root_probability",
        roots(third) == roots(outputs["b4__three_root_unrelated_token"]),
        {"base": roots(third), "transformed": roots(outputs["b4__three_root_unrelated_token"])})
    return tests


def ledger_tamper(base_model, subject_output):
    tampered = json.loads(json.dumps(subject_output))
    tampered["termination_mass"]["completed_first"] = "999/1000"
    folder = RUNS / "mutations__ledger_tamper"
    folder.mkdir(parents=True, exist_ok=True)
    write_json(folder / "tampered_subject.json", tampered)
    oracle_proc = invoke("mutations__ledger_tamper__oracle",
                         [PYTHON, str(ROOT / "oracles/independent_reference.py"), str(base_model)])
    write_json(folder / "oracle.json", parsed(oracle_proc))
    compare_proc = invoke("mutations__ledger_tamper__compare",
                          [PYTHON, str(ROOT / "tests/compare_subject_oracle.py"),
                           str(folder / "tampered_subject.json"), str(folder / "oracle.json")])
    comparison = parsed(compare_proc)
    write_json(folder / "comparison.json", comparison)
    return {"id": "LEDGER_TAMPER", "status": "PASS" if compare_proc.returncode != 0 and
            comparison.get("status") == "FAIL" else "FAIL", "detected_errors": comparison.get("errors")}


def main():
    if RUNS.exists() and any(RUNS.iterdir()):
        raise SystemExit("refusing to overwrite non-empty results/runs")
    models = (
        sorted((ROOT / "models/a4").glob("*.json"))
        + sorted((ROOT / "models/b4").glob("*.json"))
        + sorted((ROOT / "models/regression").glob("*.json"))
        + sorted((ROOT / "models/reconstructed_p0").glob("*.json"))
    )
    summaries = []
    outputs = {}
    for model in models:
        expected_rejection = model.name == "forbidden_expected_injection.json"
        summary, subject, _ = run_case(model, expected_rejection=expected_rejection)
        summaries.append(summary)
        outputs[summary["case"]] = subject

    base_model = ROOT / "models/a4/true_persistent_concurrent_y.json"
    normal = outputs["a4__true_persistent_concurrent_y"]
    mutant_summary, mutant, _ = run_case(base_model, mutant=True)
    summaries.append(mutant_summary)
    outputs[mutant_summary["case"]] = mutant
    m11 = {
        "id": "M11_STRONG_CLOCK_LIFECYCLE_MUTATION",
        "status": "PASS" if probabilities(normal) != probabilities(mutant) and
        normal["y_clock_lifecycle_after_x"] != mutant["y_clock_lifecycle_after_x"] else "FAIL",
        "normal_probabilities": probabilities(normal),
        "mutant_probabilities": probabilities(mutant),
        "normal_tail": normal["conditional_tail_T_gt_1"],
        "mutant_tail": mutant["conditional_tail_T_gt_1"],
        "normal_lifecycle": normal["y_clock_lifecycle_after_x"],
        "mutant_lifecycle": mutant["y_clock_lifecycle_after_x"],
    }
    normal_oracle_path = RUNS / "a4__true_persistent_concurrent_y/oracle.json"
    mutant_subject_path = RUNS / "a4__true_persistent_concurrent_y__mutant_m11/subject.json"
    spec_proc = invoke("mutations__m11_vs_normal_spec__compare", [
        PYTHON, str(ROOT / "tests/compare_subject_oracle.py"),
        str(mutant_subject_path), str(normal_oracle_path),
    ])
    spec_comparison = parsed(spec_proc)
    spec_folder = RUNS / "mutations__m11_vs_normal_spec"
    spec_folder.mkdir(parents=True, exist_ok=True)
    write_json(spec_folder / "comparison.json", spec_comparison)
    m11["normal_spec_detected_mutation"] = (
        spec_proc.returncode != 0 and spec_comparison.get("status") == "FAIL"
    )
    if not m11["normal_spec_detected_mutation"]:
        m11["status"] = "FAIL"
    write_json(ROOT / "results/m11_strong_mutation.json", m11)
    meta = metamorphic(outputs)
    write_json(ROOT / "results/metamorphic_tests.json", meta)
    tamper = ledger_tamper(base_model, normal)
    write_json(ROOT / "results/ledger_tamper_test.json", tamper)
    overall = {
        "status": "PASS" if all(item["accepted"] for item in summaries)
        and all(item["status"] == "PASS" for item in meta)
        and m11["status"] == "PASS" and tamper["status"] == "PASS" else "FAIL",
        "cases": summaries,
        "metamorphic": meta,
        "m11": m11,
        "ledger_tamper": tamper,
    }
    write_json(ROOT / "results/v15_acceptance_summary.json", overall)
    print(json.dumps(overall, indent=2, sort_keys=True))
    return 0 if overall["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
