# R4-V1.3 实验整改与专项闭合复验

独立实验工作区。第四轮只读 TeX SHA-256 为 `91aa5c1923b41a4030777d6266b466bcfdb20011a56dd7ad26f5b59fa7810e2a`。

本工程只包含实验模型、`NEW_VALIDATION_IMPLEMENTATION`、独立参考计算、数学证书重放、真实变异、原始日志和验收材料。未修改论文或 TeX；未开展历史 Linux 源码恢复。

冻结正式批次保留一次 D2 JSON 零值类型不一致的 FAIL。该记录没有覆盖；后续 `subject_v2/v3` 在独立目录修复并加强实际 Pre/Post 持续使能检查，最终比较通过。最终门槛以 `final_adjudication.csv` 和 `reports/acceptance_report.md` 为准。

阶段 II 未收到新理论基准，状态为 `WAITING_FOR_THEORY_BASELINE`。
