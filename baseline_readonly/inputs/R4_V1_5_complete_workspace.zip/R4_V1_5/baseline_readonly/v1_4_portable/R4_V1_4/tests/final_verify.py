"""Fresh, read-only verification of V1.4 additions and mandatory regressions."""

from __future__ import annotations

import csv
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
V13 = ROOT / "baseline_readonly/v1_3_portable/R4_V1_3"
PY = sys.executable


def need(condition, label):
    if not condition:
        raise AssertionError(label)
    print(f"OK {label}")


def run(command, cwd=ROOT, expected=0):
    completed = subprocess.run(
        command, cwd=cwd, capture_output=True, text=True, timeout=30, check=False
    )
    if completed.returncode != expected:
        raise AssertionError(
            f"command exit {completed.returncode} != {expected}: {command}\n{completed.stderr}"
        )
    return completed.stdout


def verify_manifest(name):
    manifest = json.loads((ROOT / name).read_text(encoding="utf-8"))
    for relative, expected in manifest.items():
        actual = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
        if actual != expected:
            raise AssertionError(f"{name} drift: {relative}")
    need(bool(manifest), f"{name} hashes")


verify_manifest("frozen_manifest.json")
verify_manifest("results_manifest.json")
with (ROOT / "results.csv").open(newline="", encoding="utf-8") as stream:
    rows = list(csv.DictReader(stream))
need(len(rows) == 45, "formal row count")
need(not [row for row in rows if row["status"] in {"FAIL", "UNRESOLVED", "NOT_EXECUTED"}],
     "no hard experimental failure")
need(sum(row["status"] == "MUTATION_DETECTED" for row in rows) == 13,
     "thirteen mutations detected")
need(next(row for row in rows if row["test_id"] == "ALGORITHM_4_1_CONFLICT")["status"]
     == "THEORY_CONTRACT_PENDING", "theory contract remains pending")

baseline = json.loads(run([PY, "-B", "tests/reproduce_v13_failures.py"]))
need(baseline["status"] == "BASELINE_FAILURES_REPRODUCED", "four old failures reproduced")

with tempfile.TemporaryDirectory(prefix="r4v14_final_") as raw:
    temp = Path(raw)
    models = sorted((ROOT / "models/d2_baseline").glob("*.json")) + sorted(
        (ROOT / "models/d2_adversarial").glob("*.json")
    )
    need(len(models) == 10, "ten frozen D2 variants")
    for index, model in enumerate(models):
        subject = temp / f"d2_{index}.subject.json"
        oracle = temp / f"d2_{index}.oracle.json"
        subject.write_text(run([PY, "-B", "implementations/subject/cli.py", str(model)]), encoding="utf-8")
        oracle.write_text(run([PY, "-B", "oracles/d2_reference.py", str(model)]), encoding="utf-8")
        run([PY, "-B", "tests/compare_d2.py", str(subject), str(oracle)])
        print(f"OK fresh D2 {model.name}")

    unsupported = ROOT / "models/clock_mutants/first_completion_at_x.json"
    subject_rejection = subprocess.run(
        [PY, "-B", "implementations/subject/cli.py", str(unsupported)], cwd=ROOT,
        capture_output=True, text=True, timeout=30, check=False
    )
    oracle_rejection = subprocess.run(
        [PY, "-B", "oracles/d2_reference.py", str(unsupported)], cwd=ROOT,
        capture_output=True, text=True, timeout=30, check=False
    )
    need(subject_rejection.returncode == 2 and oracle_rejection.returncode != 0
         and "first completion occurs at intermediate X firing" in subject_rejection.stderr
         and "first completion occurs at intermediate X firing" in oracle_rejection.stderr,
         "first-completion intermediate model rejected")

    mutant = temp / "m11.json"
    mutant_oracle = temp / "m11_oracle.json"
    mutant.write_text(run([PY, "-B", "implementations/mutant_m11/cli.py",
                           "models/d2_baseline/A01_baseline.json"]), encoding="utf-8")
    mutant_oracle.write_text(run([PY, "-B", "oracles/m11_reference.py",
                                  "models/d2_baseline/A01_baseline.json"]), encoding="utf-8")
    comparison = json.loads(run([PY, "-B", "tests/compare_m11.py", str(mutant), str(mutant_oracle)]))
    need(comparison["status"] == "MUTATION_DETECTED"
         and comparison["mutant_internal_consistency"] == "PASS", "fresh real M11 detection")

    tampered = temp / "tampered.json"
    correct_oracle = temp / "correct_oracle.json"
    tampered.write_text(run([PY, "-B", "mutations/M_LEDGER_TAMPER.py",
                             "models/d2_baseline/A01_baseline.json"]), encoding="utf-8")
    correct_oracle.write_text(run([PY, "-B", "oracles/d2_reference.py",
                                   "models/d2_baseline/A01_baseline.json"]), encoding="utf-8")
    tamper_output = run([PY, "-B", "tests/compare_d2.py", str(tampered), str(correct_oracle)], expected=1)
    need("category_bucket_frontier_balance" in tamper_output, "ledger-only tamper rejected")

    # C04, R06 and P03 use the unchanged V1.3 subject plus an independent subset oracle.
    regression_cases = [
        ("C04", "models/c04_regression/a1_v1_1_regression.json", "A1"),
        ("C04", "models/c04_regression/a2_true_infeasible.json", "A2"),
        ("C04", "models/c04_regression/endpoint_feasible.json", "A_ENDPOINT"),
        ("C04", "models/c04_regression/tail_fault_after_visible.json", "A_TAIL"),
        ("R06_BASE", "models/r06_observation/legal_mixed_network.json", "R06_BASE"),
        ("P03", "models/probability_multihistory/p03_y_uniform_0_1.json", "P03_U01"),
        ("P03", "models/probability_multihistory/p03_y_uniform_0_2.json", "P03_U02"),
        ("P03", "models/probability_multihistory/p03_y_uniform_0_3_2.json", "P03_U032"),
    ]
    for index, (operation, model, oracle_case) in enumerate(regression_cases):
        actual = temp / f"reg_{index}.actual.json"
        expected = temp / f"reg_{index}.expected.json"
        actual.write_text(run([PY, "-B", "implementations/subject_v5/cli.py", operation, model], V13), encoding="utf-8")
        expected.write_text(run([PY, "-B", "oracles/reference.py", oracle_case], V13), encoding="utf-8")
        run([PY, "-B", "tests/compare.py", str(actual), str(expected)], V13)
    print("OK fresh C04/R06/P03 regressions")

    for channel, oracle_case in (("on", "CHANNEL_ON"), ("off", "CHANNEL_OFF")):
        actual = temp / f"channel_{channel}.actual.json"
        expected = temp / f"channel_{channel}.expected.json"
        actual.write_text(run([PY, "-B", "implementations/subject_v5/cli.py", "CHANNEL",
                               "models/r06_observation/discriminative_completion_channel.json", channel], V13), encoding="utf-8")
        expected.write_text(run([PY, "-B", "oracles/reference.py", oracle_case], V13), encoding="utf-8")
        run([PY, "-B", "tests/compare.py", str(actual), str(expected)], V13)
    print("OK fresh completion-channel on/off")

    run([PY, "-B", "implementations/certificate_verifier_v3/cli.py",
         "models/r04_certificates/cert_pass_network.json", "certificates/valid/pass_exact_replay.json"], V13)
    run([PY, "-B", "implementations/certificate_verifier_v3/cli.py",
         "models/r04_certificates/cert_pass_network.json", "certificates/forged/in_range_wrong_result.json"], V13, expected=2)
    run([PY, "-B", "implementations/certificate_verifier_v3/cli.py",
         "models/r04_certificates/cert_pass_network.json", "certificates/forged/modified_intermediate.json"], V13, expected=2)
    print("OK fresh R04 valid and forged certificates")

    e_models = ["e1_disjoint_v13.json", "e2_endpoint_v13.json", "e3_overlap_v13.json"]
    for index, name in enumerate(e_models):
        logical = temp / f"e{index}.logical.json"
        probability = temp / f"e{index}.probability.json"
        logical.write_text(run([PY, "-B", "implementations/subject_v5/logical_module.py",
                                f"models/cross_layer/{name}"], V13), encoding="utf-8")
        probability.write_text(run([PY, "-B", "implementations/subject_v5/probability_module.py",
                                    f"models/cross_layer/{name}"], V13), encoding="utf-8")
        aligned = json.loads(run([PY, "-B", "implementations/subject_v5/alignment.py",
                                  str(logical), str(probability)], V13))
        need(aligned["aligned"], f"fresh E{index + 1} alignment")

    logical = temp / "e_negative.logical.json"
    probability = temp / "e_negative.probability.json"
    logical.write_text(run([PY, "-B", "implementations/subject_v5/logical_module.py",
                            "models/cross_layer/e3_overlap_v13.json"], V13), encoding="utf-8")
    probability.write_text(run([PY, "-B", "implementations/subject_v5/probability_module.py",
                                "models/cross_layer/e3_overlap_v13.json", "--channel-off"], V13), encoding="utf-8")
    run([PY, "-B", "implementations/subject_v5/alignment.py", str(logical), str(probability)], V13, expected=3)
    probability.write_text(run([PY, "-B", "implementations/subject_v5/probability_module.py",
                                "models/cross_layer/e3_overlap_v13.json", "--coarsen"], V13), encoding="utf-8")
    run([PY, "-B", "implementations/subject_v5/alignment.py", str(logical), str(probability)], V13, expected=3)
    print("OK fresh E channel/coarsening negative tests")

regression = json.loads((ROOT / "runs/regression/frozen_v13_replay/regression_summary.json").read_text())
need(regression["status"] == "PASS" and all(item["pass"] for item in regression["checks"].values()),
     "full isolated regression summary")
need(not any(path.is_symlink() for path in ROOT.rglob("*")), "no symlinks")
print("FINAL_VERIFY PASS")
